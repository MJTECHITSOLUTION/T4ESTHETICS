<?php

namespace Modules\Customer\Http\Controllers\Backend;

use App\Authorizable;
use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Modules\Booking\Models\Booking;
use Modules\Customer\Http\Requests\CustomerRequest;
use Modules\CustomField\Models\CustomField;
use Modules\CustomField\Models\CustomFieldGroup;
use Modules\Customer\Models\DevisUser;
use Modules\Customer\Models\DevisDetail;
use Modules\Package\Models\Package;
use Modules\Tax\Models\Tax;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Yajra\DataTables\DataTables;
use Modules\Customer\Models\MedicalRecord;
use Modules\Customer\Models\MedicalHistory;
use Modules\Customer\Models\MedicalHistoryType;
use Illuminate\Support\Facades\Storage;

class CustomersController extends Controller
{
    // use Authorizable;
    protected string $exportClass = '\App\Exports\CustomerExport';
    protected string $module_title;
    protected string $module_name;
    protected string $module_path;

    public function __construct()
    {
        // Page Title
        $this->module_title = 'customer.title';

        // module name
        $this->module_name = 'customers';

        // directory path of the module
        $this->module_path = 'customer::backend';

        view()->share([
            'module_title' => $this->module_title,
            'module_icon' => 'fa-regular fa-sun',
            'module_name' => $this->module_name,
            'module_path' => $this->module_path,
        ]);
        $this->middleware(['permission:view_customer'])->only('index', 'show');
        $this->middleware(['permission:edit_customer'])->only('edit', 'update');
        $this->middleware(['permission:add_customer'])->only('store');
        $this->middleware(['permission:delete_customer'])->only('destroy');
    }

    public function bulk_action(Request $request)
    {
        $ids = explode(',', $request->rowIds);

        $actionType = $request->action_type;

        $message = __('messages.bulk_update');

        // dd($actionType, $ids, $request->status);
        switch ($actionType) {
            case 'change-status':
                $customer = User::whereIn('id', $ids)->update(['status' => $request->status]);
                $message = __('messages.bulk_customer_update');
                break;

            case 'delete':
                if (env('IS_DEMO')) {
                    return response()->json(['message' => __('messages.permission_denied'), 'status' => false], 200);
                }
                User::whereIn('id', $ids)->delete();
                $message = __('messages.bulk_customer_delete');
                break;

            default:
                return response()->json(['status' => false, 'message' => __('branch.invalid_action')]);
                break;
        }

        return response()->json(['status' => true, 'message' => __('messages.bulk_update')]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        $module_action = 'List';
        $columns = CustomFieldGroup::columnJsonValues(new User());
        $customefield = CustomField::exportCustomFields(new User());

        $export_import = true;
        $export_columns = [
            [
                'value' => 'first_name',
                'text' => 'First Name',
            ],
            [
                'value' => 'last_name',
                'text' => 'Last Name',
            ],
            [
                'value' => 'email',
                'text' => 'E-mail',
            ],
            [
                'value' => 'varification_status',
                'text' => 'Verification Status',
            ],
            [
                'value' => 'is_banned',
                'text' => 'Banned',
            ],
            [
                'value' => 'status',
                'text' => 'Status',
            ],
        ];
        $export_url = route('backend.customers.export');

        return view('customer::backend.customers.index', compact('module_action', 'columns', 'customefield', 'export_import', 'export_columns', 'export_url'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $module_action = 'Show';
        $data = User::findOrFail($id);

        if (! is_null($data)) {
            $custom_field_data = $data->withCustomFields();
            $data['custom_field_data'] = collect($custom_field_data->custom_fields_data)
                ->filter(function ($value) {
                    return $value !== null;
                })
                ->toArray();
        }

        $data['profile_image'] = $data->profile_image;

        return view('customer::backend.customers.show', compact('module_action', 'data'));
    }

    public function update_status(Request $request, User $id)
    {
        $id->update(['status' => $request->status]);

        return response()->json(['status' => true, 'message' => __('branch.status_update')]);
    }

    public function index_data(Datatables $datatable, Request $request)
    {
        $module_name = $this->module_name;
        $query = User::role('user');

        $filter = $request->filter;

        if (isset($filter)) {
            if (isset($filter['column_status'])) {
                $query->where('status', $filter['column_status']);
            }
        }

        $datatable = $datatable->eloquent($query)
            ->addColumn('check', function ($row) {
                return '<input type="checkbox" class="form-check-input select-table-row"  id="datatable-row-'.$row->id.'"  name="datatable_ids[]" value="'.$row->id.'" onclick="dataTableRowCheck('.$row->id.')">';
            })
            ->addColumn('action', function ($data) use ($module_name) {
                return view('customer::backend.customers.action_column', compact('module_name', 'data'));
            })

            // ->editColumn('image', function ($data) {
            //     return "<img src='".$data->profile_image."'class='avatar avatar-50 rounded-pill'>";
            // })

            ->addColumn('user_id', function ($data) {
                $Profile_image = optional($data)->profile_image ?? default_user_avatar();
                $name =optional($data)->full_name ?? default_user_name() ;
                $email =  optional($data)->email ?? '--' ;
                return view('booking::backend.bookings.datatable.user_id', compact('Profile_image','name','email'));
                // return view('employee::backend.employees.employee_id', compact('data'));
            })
            ->orderColumn('user_id', function ($query, $order) {
                $query->orderBy('users.first_name', $order) // Ordering by first name
                      ->orderBy('users.last_name', $order); // Optional: also order by last name
            }, 1)
            ->filterColumn('user_id', function ($query, $keyword) {
                if (!empty($keyword)) {
                    // Assuming 'users' table has first_name and last_name
                    $query->where(function ($query) use ($keyword) {
                        $query->where('first_name', 'like', '%' . $keyword . '%')
                              ->orWhere('last_name', 'like', '%' . $keyword . '%') // Filtering by last name
                              ->orWhere('email', 'like', '%' . $keyword . '%');
                    });
                }
            })
            
            
            // ->editColumn('user_id', function ($data) {
            //     return  $data->first_name . ' ' . $data->last_name;
            // })

            ->editColumn('email_verified_at', function ($data) {
                $checked = '';
                if ($data->email_verified_at) {
                    return '<span class="badge bg-soft-success"><i class="fa-solid fa-envelope" style="margin-right: 2px"></i> '.__('customer.msg_verified').'</span>';
                }

                return '<button  type="button" data-url="'.route('backend.customers.verify-customer', $data->id).'" data-token="'.csrf_token().'" class="button-status-change btn btn-text-danger btn-sm  bg-soft-danger"  id="datatable-row-'.$data->id.'"  name="is_verify" value="'.$data->id.'" '.$checked.'>Verify</button>';
            })

            ->editColumn('is_banned', function ($data) {
                $checked = '';
                if ($data->is_banned) {
                    $checked = 'checked="checked"';
                }

                return '
                    <div class="form-check form-switch ">
                        <input type="checkbox" data-url="'.route('backend.customers.block-customer', $data->id).'" data-token="'.csrf_token().'" class="switch-status-change form-check-input"  id="datatable-row-'.$data->id.'"  name="is_banned" value="'.$data->id.'" '.$checked.'>
                    </div>
                 ';
            })

            ->editColumn('status', function ($row) {
                $checked = '';
                if ($row->status) {
                    $checked = 'checked="checked"';
                }

                return '
                    <div class="form-check form-switch ">
                        <input type="checkbox" data-url="'.route('backend.customers.update_status', $row->id).'" data-token="'.csrf_token().'" class="switch-status-change form-check-input"  id="datatable-row-'.$row->id.'"  name="status" value="'.$row->id.'" '.$checked.'>
                    </div>
                ';
            })
            ->editColumn('updated_at', function ($data) {
                $module_name = $this->module_name;

                $diff = Carbon::now()->diffInHours($data->updated_at);

                if ($diff < 25) {
                    return $data->updated_at->diffForHumans();
                } else {
                    return $data->updated_at->isoFormat('llll');
                }
            })
            
            // ->filterColumn('user_id', function ($query, $keyword) {
            //     if (!empty($keyword)) {   
            //             $query->whereRaw('CONCAT(first_name, " ", last_name) LIKE ?', ['%' . $keyword . '%']);
            //     }
            // })

            ->orderColumns(['id'], '-:column $1');

        // Custom Fields For export
        $customFieldColumns = CustomField::customFieldData($datatable, User::CUSTOM_FIELD_MODEL, null);

        return $datatable->rawColumns(array_merge(['user_id','action', 'status', 'is_banned', 'email_verified_at', 'check', 'image'], $customFieldColumns))
            ->toJson();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(CustomerRequest $request)
    {
        $data = $request->all();

        $data = User::create($data);

        $data->syncRoles(['user']);

        Artisan::call('cache:clear');

        if ($request->custom_fields_data) {
            $data->updateCustomFieldData(json_decode($request->custom_fields_data));
        }

        if ($request->has('profile_image')) {
            $request->file('profile_image');

            storeMediaFile($data, $request->file('profile_image'), 'profile_image');
        }

        $message = __('messages.create_form', ['form' => __('customer.singular_title')]);

        return response()->json(['message' => $message, 'status' => true], 200);
    }

    public function edit($id)
    {
        $data = User::findOrFail($id);

        if (! is_null($data)) {
            $custom_field_data = $data->withCustomFields();
            $data['custom_field_data'] = collect($custom_field_data->custom_fields_data)
                ->filter(function ($value) {
                    return $value !== null;
                })
                ->toArray();
        }

        $data['profile_image'] = $data->profile_image;

        return response()->json(['data' => $data, 'status' => true]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(CustomerRequest $request, $id)
    {
        $data = User::findOrFail($id);

        $request_data = $request->except('profile_image');

        $data->update($request_data);
        if ($request->custom_fields_data) {
            $data->updateCustomFieldData(json_decode($request->custom_fields_data));
        }

        if ($request->hasFile('profile_image')) {
            storeMediaFile($data, $request->file('profile_image'), 'profile_image');
        }
        if ($request->profile_image == null) {
            $data->clearMediaCollection('profile_image');
        }
        $message = __('messages.update_form', ['form' => __('customer.singular_title')]);

        return response()->json(['message' => $message, 'status' => true], 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy($id)
    {
        if (env('IS_DEMO')) {
            return response()->json(['message' => __('messages.permission_denied'), 'status' => false], 200);
        }
        $data = User::findOrFail($id);
        
        $booking = Booking::where('user_id', $id)->where('status', '!=', 'completed')->update(['status' => 'cancelled']);

        $data->tokens()->delete();

        $data->forceDelete();

        $message = __('messages.delete_form', ['form' => __('customer.singular_title')]);

        return response()->json(['message' => $message, 'status' => true], 200);
    }

    /**
     * List of trashed ertries
     * works if the softdelete is enabled.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function trashed()
    {
        $module_name = $this->module_name;

        $module_name_singular = Str::singular($module_name);

        $module_action = 'Trash List';

        $data = User::onlyTrashed()->orderBy('deleted_at', 'desc')->paginate();

        return view('customer::backend.customers.trash', compact('data', 'module_name_singular', 'module_action'));
    }

    /**
     * Restore a soft deleted entry.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function restore($id)
    {
        $module_action = 'Restore';

        $data = User::withTrashed()->find($id);
        $data->restore();

        return redirect('app/customers');
    }

    public function change_password(Request $request)
    {
        $data = $request->all();

        $user_id = $data['user_id'];

        $data = User::findOrFail($user_id);

        $request_data = $request->only('password');
        $request_data['password'] = Hash::make($request_data['password']);

        $data->update($request_data);

        $message = __('messages.password_update');

        return response()->json(['message' => $message, 'status' => true], 200);
    }

    public function block_customer(Request $request, User $id)
    {
        $id->update(['is_banned' => $request->status]);

        if ($request->status == 1) {
            $message = __('messages.google_blocked');
        } else {
            $message = __('messages.google_unblocked');
        }

        return response()->json(['status' => true, 'message' => $message]);
    }

    public function verify_customer(Request $request, $id)
    {
        $data = User::findOrFail($id);

        $current_time = Carbon::now();

        $data->update(['email_verified_at' => $current_time]);

        return response()->json(['status' => true, 'message' => __('messages.customer_verify')]);
    }

    public function uniqueEmail(Request $request)
    {
        $email = $request->input('email');
        $userId = $request->input('user_id');

        $isUnique = User::where('email', $email)
                        ->where(function ($query) use ($userId) {
                            if ($userId) {
                                $query->where('id', '!=', $userId);
                            }
                        })
                        ->doesntExist();

        return response()->json(['isUnique' => $isUnique]);
    }

    /**
     * Get packages for devis creation
     */
    public function getPackages()
    {
        try {
            $packages = Package::with(['branch'])
                ->where('status', 1)
                ->select('id', 'name', 'package_price', 'description', 'end_date', 'branch_id')
                ->get()
                ->map(function ($package) {
                    return [
                        'id' => $package->id,
                        'name' => $package->name,
                        'package_price' => $package->package_price,
                        'description' => $package->description,
                        'end_date' => $package->end_date,
                        'branch_name' => $package->branch ? $package->branch->name : 'N/A'
                    ];
                });

            return response()->json([
                'status' => true,
                'data' => $packages
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Error loading packages: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get package details with services
     */
    public function getPackageDetails(Request $request)
    {
        try {
            $packageId = $request->input('package_id');
            
            if (!$packageId) {
                return response()->json([
                    'status' => false,
                    'message' => 'Package ID is required'
                ], 400);
            }
            
            // Get package basic info
            $package = Package::with(['branch'])
                ->where('id', $packageId)
                ->where('status', 1)
                ->first();

            if (!$package) {
                return response()->json([
                    'status' => false,
                    'message' => 'Package not found'
                ], 404);
            }

            // Get package services separately to avoid relationship issues
            $packageServices = DB::table('package_services')
                ->where('package_id', $packageId)
                ->get();

            $packageData = [
                'id' => $package->id,
                'name' => $package->name,
                'package_price' => $package->package_price,
                'description' => $package->description,
                'end_date' => $package->end_date,
                'branch_name' => $package->branch ? $package->branch->name : 'N/A',
                'services' => $packageServices->map(function ($packageService) {
                    return [
                        'id' => $packageService->id,
                        'service_id' => $packageService->service_id,
                        'service_name' => $packageService->service_name,
                        'service_price' => $packageService->service_price,
                        'quantity' => $packageService->qty,
                        'discount_price' => $packageService->discounted_price,
                        'duration_min' => 0 // We'll set this to 0 for now to avoid additional queries
                    ];
                })
            ];

            return response()->json([
                'status' => true,
                'data' => [$packageData]
            ]);
        } catch (\Exception $e) {
            Log::error('Package Details Error: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Error loading package details: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get taxes for devis creation
     */
    public function getTaxes()
    {
        try {
            $taxes = Tax::where('status', 1)
                ->select('id', 'title', 'type', 'value')
                ->get();

            return response()->json([
                'status' => true,
                'data' => $taxes
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Error loading taxes: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Save devis
     */
    public function saveDevis(Request $request)
    {
        try {
            $request->validate([
                'customer_id' => 'required|exists:users,id',
                'package_id' => 'nullable|exists:packages,id',
                'services' => 'required|array|min:1',
                'services.*.service_name' => 'required|string|max:255',
                'services.*.quantity' => 'required|integer|min:1',
                'services.*.price' => 'required|numeric|min:0',
                'services.*.discount' => 'nullable|numeric|min:0',
                'services.*.number_of_lot' => 'nullable|string|max:255',
                'tax_rate' => 'nullable|numeric|min:0|max:100',
                'remarks' => 'nullable|string',
                'received_at' => 'nullable|date',
                'accepted_at' => 'nullable|date',
                'signature_image' => 'nullable|string'
            ]);

            // Calculate totals
            $subtotal = 0;
            $totalTaxAmount = 0;
            
            foreach ($request->services as $service) {
                $serviceSubtotal = $service['quantity'] * ($service['price'] - ($service['discount'] ?? 0));
                $serviceTvaRate = $service['tva_rate'] ?? 0;
                $serviceTaxAmount = ($serviceSubtotal * $serviceTvaRate) / 100;
                
                $subtotal += $serviceSubtotal;
                $totalTaxAmount += $serviceTaxAmount;
            }
            
            $totalAmount = $subtotal + $totalTaxAmount;

            // Optionally handle signature image (base64 data URL)
            $signaturePath = null;
            if ($request->filled('signature_image') && is_string($request->signature_image)) {
                try {
                    $dataUrl = $request->signature_image;
                    if (strpos($dataUrl, 'data:image') === 0) {
                        $matches = [];
                        if (preg_match('/^data:image\/(png|jpeg|jpg);base64,(.*)$/', $dataUrl, $matches)) {
                            $ext = $matches[1] === 'jpeg' ? 'jpg' : $matches[1];
                            $base64 = $matches[2];
                            $base64 = str_replace(' ', '+', $base64);
                            $binary = base64_decode($base64);
                            if ($binary !== false) {
                                $dir = 'signatures';
                                $fileName = $dir . '/devis_' . time() . '_' . uniqid('', true) . '.' . $ext;
                                Storage::disk('public')->put($fileName, $binary);
                                $signaturePath = $fileName;
                            }
                        }
                    }
                } catch (\Throwable $th) {
                    Log::warning('Failed to store signature image: ' . $th->getMessage());
                }
            }

            // Create devis user record
            $devisUser = DevisUser::create([
                'customer_id' => $request->customer_id,
                'package_id' => $request->package_id,
                'devis_number' => DevisUser::generateDevisNumber(),
                'subtotal' => $subtotal,
                'tax_rate' => 0, // We're using individual TVA rates now
                'tax_amount' => $totalTaxAmount,
                'total_amount' => $totalAmount,
                'remarks' => $request->remarks,
                'received_at' => $request->received_at,
                'accepted_at' => $request->accepted_at,
                'signature_path' => $signaturePath,
                'status' => 'draft',
                'valid_until' => now()->addDays(30), // 30 days validity
                'created_by' => auth()->id(),
                'updated_by' => auth()->id()
            ]);

            // Create devis details
            foreach ($request->services as $service) {
                $serviceSubtotal = $service['quantity'] * ($service['price'] - ($service['discount'] ?? 0));
                $serviceTvaRate = $service['tva_rate'] ?? 0;
                $serviceTaxAmount = ($serviceSubtotal * $serviceTvaRate) / 100;
                $serviceTotal = $serviceSubtotal + $serviceTaxAmount;

                DevisDetail::create([
                    'devis_user_id' => $devisUser->id,
                    'service_name' => $service['service_name'],
                    'service_id' => $service['service_id'] ?? null,
                    'quantity' => $service['quantity'],
                    'price' => $service['price'],
                    'discount' => $service['discount'] ?? 0,
                    'subtotal' => $serviceSubtotal,
                    'tax_amount' => $serviceTaxAmount,
                    'total' => $serviceTotal,
                    'remarks' => $service['remarks'] ?? null,
                    'number_of_lot' => $service['number_of_lot'] ?? null,
                    'created_by' => auth()->id(),
                    'updated_by' => auth()->id()
                ]);
            }

            return response()->json([
                'status' => true,
                'message' => 'Devis saved successfully',
                'data' => [
                    'devis_id' => $devisUser->id,
                    'devis_number' => $devisUser->devis_number,
                    'total_amount' => $devisUser->total_amount,
                    'signature_image_url' => ($devisUser->signature_path ?? null) ? asset('storage/'.$devisUser->signature_path) : null
                ]
            ]);

        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors()
            ], 422);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Error saving devis: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get customer devis list
     */
    public function getCustomerDevis($customerId)
    {
        try {
            Log::info('Loading devis for customer ID: ' . $customerId);
            
            // Get devis with relationships
            $devisList = DevisUser::with(['devisDetails', 'package'])
                ->where('customer_id', $customerId)
                ->orderBy('created_at', 'desc')
                ->get();

            Log::info('Found ' . $devisList->count() . ' devis for customer');

            // Transform the data for frontend
            $transformedData = $devisList->map(function ($devis) {
                return [
                    'id' => $devis->id,
                    'devis_number' => $devis->devis_number,
                    'package' => $devis->package ? [
                        'id' => $devis->package->id,
                        'name' => $devis->package->name
                    ] : null,
                    'subtotal' => $devis->subtotal,
                    'tax_amount' => $devis->tax_amount,
                    'total_amount' => $devis->total_amount,
                    'status' => $devis->status,
                    'created_at' => $devis->created_at,
                    'valid_until' => $devis->valid_until,
                    'remarks' => $devis->remarks,
                    'signature_image_url' => (isset($devis->signature_path) && $devis->signature_path) ? asset('storage/'.$devis->signature_path) : null,
                    'devis_details' => $devis->devisDetails->map(function ($detail) {
                        return [
                            'id' => $detail->id,
                            'service_name' => $detail->service_name,
                            'quantity' => $detail->quantity,
                            'price' => $detail->price,
                            'discount' => $detail->discount,
                            'subtotal' => $detail->subtotal,
                            'tax_amount' => $detail->tax_amount,
                            'total' => $detail->total,
                            'remarks' => $detail->remarks
                        ];
                    })
                ];
            });

            return response()->json([
                'status' => true,
                'data' => $transformedData
            ]);
        } catch (\Exception $e) {
            Log::error('Error loading devis for customer ' . $customerId . ': ' . $e->getMessage());
            Log::error('Stack trace: ' . $e->getTraceAsString());
            
            return response()->json([
                'status' => false,
                'message' => 'Error loading devis: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update devis status
     */
    public function updateDevisStatus(Request $request, $devisId)
    {
        try {
            $request->validate([
                'status' => 'required|in:draft,sent,accepted,rejected,expired'
            ]);

            $devis = DevisUser::findOrFail($devisId);
            $devis->update(['status' => $request->status]);

            return response()->json([
                'status' => true,
                'message' => 'Devis status updated successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Error updating devis status: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Test devis functionality
     */
    public function testDevis($customerId)
    {
        try {
            Log::info('Test devis for customer ID: ' . $customerId);
            
            // Test if DevisUser model exists
            $modelExists = class_exists(DevisUser::class);
            
            // Test if table exists
            $tableExists = false;
            $devisCount = 0;
            $error = null;
            
            try {
                $devisCount = DevisUser::where('customer_id', $customerId)->count();
                $tableExists = true;
            } catch (\Exception $e) {
                $error = $e->getMessage();
                Log::error('Table query error: ' . $e->getMessage());
            }
            
            return response()->json([
                'status' => true,
                'message' => 'Test completed',
                'customer_id' => $customerId,
                'devis_count' => $devisCount,
                'model_exists' => $modelExists,
                'table_exists' => $tableExists,
                'error' => $error
            ]);
        } catch (\Exception $e) {
            Log::error('Test devis error: ' . $e->getMessage());
            
            return response()->json([
                'status' => false,
                'message' => 'Test failed: ' . $e->getMessage(),
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Delete devis
     */
    public function deleteDevis($devisId)
    {
        try {
            Log::info('Deleting devis ID: ' . $devisId);
            
            // Find the devis
            $devis = DevisUser::find($devisId);
            
            if (!$devis) {
                return response()->json([
                    'status' => false,
                    'message' => 'Devis not found'
                ], 404);
            }
            
            // Delete devis details first (due to foreign key constraint)
            $devis->devisDetails()->delete();
            
            // Delete the main devis record using direct database deletion
            // to avoid BaseModel's deleted_by column requirement
            DB::table('devis_user')->where('id', $devisId)->delete();
            
            Log::info('Devis deleted successfully: ' . $devisId);
            
            return response()->json([
                'status' => true,
                'message' => 'Devis deleted successfully'
            ]);
            
        } catch (\Exception $e) {
            Log::error('Error deleting devis ' . $devisId . ': ' . $e->getMessage());
            Log::error('Stack trace: ' . $e->getTraceAsString());
            
            return response()->json([
                'status' => false,
                'message' => 'Error deleting devis: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Stream latest devis PDF for a customer
     */
    public function printDevis($customerId)
    {
        try {
            $customer = User::findOrFail((int) $customerId);

            $devis = DevisUser::with('devisDetails')
                ->where('customer_id', $customerId)
                ->latest('created_at')
                ->first();

            if (!$devis) {
                return abort(404, 'No devis found for this customer');
            }

            $html = View::make('customer::backend.customers.devis-pdf', [
                'customer' => $customer,
                'devis' => $devis,
            ])->render();

            $pdf = Pdf::loadHTML($html);
            return $pdf->stream('devis_'.$devis->devis_number.'.pdf');
        } catch (\Exception $e) {
            Log::error('Print devis error: '.$e->getMessage());
            return abort(500, 'Failed to generate PDF');
        }
    }

    /**
     * Print specific devis PDF by devis ID
     */
    public function printDevisPdf($devisId)
    {
        try {
            $devis = DevisUser::with(['devisDetails', 'customer'])
                ->findOrFail($devisId);

            $html = View::make('customer::backend.customers.devis-pdf', [
                'customer' => $devis->customer,
                'devis' => $devis,
            ])->render();

            $pdf = Pdf::loadHTML($html);
            return $pdf->stream('devis_'.$devis->devis_number.'.pdf');
        } catch (\Exception $e) {
            Log::error('Print devis PDF error: '.$e->getMessage());
            return abort(500, 'Failed to generate PDF');
        }
    }

    /**
     * Medical Records: list for a customer
     */
    public function getMedicalRecords($customerId)
    {
        try {
            $records = MedicalRecord::where('customer_id', (int) $customerId)
                ->latest('created_at')
                ->get()
                ->map(function ($rec) {
                    return [
                        'id' => $rec->id,
                        'title' => $rec->title,
                        'note' => $rec->note,
                        'file_name' => $rec->file_name,
                        'file_url' => $rec->file_url,
                        'mime_type' => $rec->mime_type,
                        'file_size' => $rec->file_size,
                        'created_at' => $rec->created_at,
                        'updated_at' => $rec->updated_at,
                    ];
                });

            return response()->json([
                'status' => true,
                'data' => $records,
            ]);
        } catch (\Throwable $e) {
            Log::error('Medical records load error: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Error loading medical records: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Medical Records: store a document for a customer
     */
    public function storeMedicalRecord(Request $request, $customerId)
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'note' => 'nullable|string',
                'document' => 'required|file|max:10240|mimes:pdf,jpg,jpeg,png,doc,docx,xls,xlsx',
            ]);

            $resolvedCustomerId = (int) ($request->input('customer_id') ?: $customerId);
            if ($resolvedCustomerId <= 0) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid customer id',
                ], 422);
            }
            $user = User::findOrFail($resolvedCustomerId);

            $path = null;
            $fileName = null;
            $mime = null;
            $size = null;

            if ($request->hasFile('document')) {
                $file = $request->file('document');
                $mime = $file->getMimeType();
                $size = $file->getSize();
                $fileName = $file->getClientOriginalName();
                $path = $file->store('medical_records/'.(int)$user->id, 'public');
            }

            $rec = MedicalRecord::create([
                'customer_id' => $user->id,
                'title' => $request->input('title'),
                'note' => $request->input('note'),
                'file_name' => $fileName,
                'file_path' => $path,
                'mime_type' => $mime,
                'file_size' => $size,
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Document uploaded successfully',
                'data' => [
                    'id' => $rec->id,
                    'file_url' => $rec->file_url,
                ],
            ]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Throwable $e) {
            Log::error('Medical record store error: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'Error saving document: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Medical Records: delete a document
     */
    public function deleteMedicalRecord($recordId)
    {
        try {
            $rec = MedicalRecord::find($recordId);
            if (!$rec) {
                return response()->json([
                    'status' => false,
                    'message' => 'Document not found',
                ], 404);
            }

            // delete file if present
            if ($rec->file_path) {
                try {
                    Storage::disk('public')->delete($rec->file_path);
                } catch (\Throwable $e) {
                    Log::warning('Failed to delete medical file: ' . $e->getMessage());
                }
            }

            $rec->delete();

            return response()->json([
                'status' => true,
                'message' => 'Document deleted',
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'status' => false,
                'message' => 'Error deleting document: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Medical History: list items for a customer
     */
    public function getMedicalHistory($customerId)
    {
        try {
            $items = MedicalHistory::with('type')
                ->where('customer_id', (int) $customerId)
                ->latest('created_at')
                ->get()
                ->map(function ($h) {
                    return [
                        'id' => $h->id,
                        'title' => $h->title,
                        'type' => $h->type ? ['id' => $h->type->id, 'name' => $h->type->name] : null,
                        'detail' => $h->detail,
                        'medication' => $h->medication,
                        'start_date' => $h->start_date,
                        'end_date' => $h->end_date,
                        'created_at' => $h->created_at,
                    ];
                });

            return response()->json(['status' => true, 'data' => $items]);
        } catch (\Throwable $e) {
            Log::error('Medical history load error: '.$e->getMessage());
            return response()->json(['status' => false, 'message' => 'Error loading medical history'], 500);
        }
    }

    /**
     * Medical History: create item
     */
    public function storeMedicalHistory(Request $request, $customerId)
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'type_id' => 'required|exists:medical_history_types,id',
                'detail' => 'nullable|string',
                'medication' => 'nullable|string',
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
            ]);

            $resolvedCustomerId = (int) ($request->input('customer_id') ?: $customerId);
            if ($resolvedCustomerId <= 0) {
                return response()->json(['status' => false, 'message' => 'Invalid customer id'], 422);
            }
            $user = User::findOrFail($resolvedCustomerId);

            $item = MedicalHistory::create([
                'customer_id' => $user->id,
                'title' => $request->input('title'),
                'type_id' => $request->input('type_id'),
                'detail' => $request->input('detail'),
                'medication' => $request->input('medication'),
                'start_date' => $request->input('start_date'),
                'end_date' => $request->input('end_date'),
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            return response()->json(['status' => true, 'message' => 'History added', 'data' => $item->load('type')]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['status' => false, 'message' => 'Validation failed', 'errors' => $e->errors()], 422);
        } catch (\Throwable $e) {
            Log::error('Medical history store error: '.$e->getMessage());
            return response()->json(['status' => false, 'message' => 'Error saving history'], 500);
        }
    }

    /**
     * Medical History: delete item
     */
    public function deleteMedicalHistory($historyId)
    {
        try {
            $item = MedicalHistory::find($historyId);
            if (!$item) {
                return response()->json(['status' => false, 'message' => 'Item not found'], 404);
            }
            $item->delete();
            return response()->json(['status' => true, 'message' => 'History deleted']);
        } catch (\Throwable $e) {
            return response()->json(['status' => false, 'message' => 'Error deleting history'], 500);
        }
    }

    /**
     * Medical History Types
     */
    public function getMedicalHistoryTypes()
    {
        $types = MedicalHistoryType::orderBy('name')->get(['id','name']);
        return response()->json(['status' => true, 'data' => $types]);
    }

    public function storeMedicalHistoryType(Request $request)
    {
        try {
            $request->validate(['name' => 'required|string|max:191|unique:medical_history_types,name']);
            $type = MedicalHistoryType::create([
                'name' => $request->input('name'),
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);
            return response()->json(['status' => true, 'message' => 'Type created', 'data' => $type]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json(['status' => false, 'message' => 'Validation failed', 'errors' => $e->errors()], 422);
        }
    }
}
