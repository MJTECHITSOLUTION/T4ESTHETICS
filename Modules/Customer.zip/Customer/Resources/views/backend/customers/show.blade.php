@extends('backend.layouts.app')

@section('title')
{{ __($module_action) }} {{ __($module_title) }}
@endsection

@push('after-styles')
<link rel="stylesheet" href="{{ mix('modules/constant/style.css') }}">
<style>
    .customer-profile-header {
        /* background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); */
        color: white;
        border-radius: 15px 15px 0 0;
        padding: 2rem;
        margin-bottom: 0;
    }
    
    .profile-avatar {
        width: 120px;
        height: 120px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    }
    
    .nav-tabs-custom {
        border: none;
        background: #f8f9fa;
        border-radius: 0 0 15px 15px;
        padding: 0 2rem;
    }
    
    .nav-tabs-custom .nav-link {
        border: none;
        color: #6c757d;
        font-weight: 500;
        padding: 1rem 1.5rem;
        border-radius: 0;
        position: relative;
        transition: all 0.3s ease;
    }
    
    .nav-tabs-custom .nav-link:hover {
        color: #495057;
        background: transparent;
    }
    
    .nav-tabs-custom .nav-link.active {
        color: #667eea;
        background: white;
        border: none;
        border-bottom: 3px solid #667eea;
    }
    
    .tab-content-custom {
        background: white;
        border-radius: 0 0 15px 15px;
        padding: 2rem;
        min-height: 400px;
    }
    
    .info-card {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        transition: all 0.3s ease;
    }
    
    .info-card:hover {
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        transform: translateY(-2px);
    }
    
    .info-label {
        font-size: 0.875rem;
        font-weight: 600;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.5rem;
    }
    
    .info-value {
        font-size: 1rem;
        color: #495057;
        font-weight: 500;
    }
    
    .status-badge {
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
        font-weight: 500;
    }
    
    .custom-fields-section {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 1.5rem;
        margin-top: 2rem;
    }
    
    .empty-tab {
        text-align: center;
        padding: 4rem 2rem;
        color: #6c757d;
    }
    
    .empty-tab i {
        font-size: 4rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }
    
    /* Modal Styling */
    .devis-step {
        min-height: 300px;
    }
    
    .service-item {
        background: #f8f9fa;
        border: 1px solid #e9ecef !important;
        transition: all 0.3s ease;
    }
    
    .service-item:hover {
        background: #ffffff;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    
    .service-item .form-control-sm {
        font-size: 0.875rem;
        padding: 0.375rem 0.5rem;
    }
    
    .service-item .form-label.small {
        font-size: 0.75rem;
        font-weight: 600;
        color: #6c757d;
        margin-bottom: 0.25rem;
    }
    
    .modal-xl {
        max-width: 1200px;
    }
    
    .step-indicator {
        display: flex;
        justify-content: center;
        margin-bottom: 2rem;
    }
    
    .step-indicator .step {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: #e9ecef;
        color: #6c757d;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 10px;
        font-weight: 600;
        position: relative;
    }
    
    .step-indicator .step.active {
        background: #667eea;
        color: white;
    }
    
    .step-indicator .step.completed {
        background: #28a745;
        color: white;
    }
    
    .step-indicator .step:not(:last-child)::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 100%;
        width: 20px;
        height: 2px;
        background: #e9ecef;
        transform: translateY(-50%);
    }
    
    .step-indicator .step.completed:not(:last-child)::after {
        background: #28a745;
    }
    
    /* Devis List Styling */
    #devis-list-table {
        font-size: 0.9rem;
    }
    
    #devis-list-table th {
        background-color: #f8f9fa;
        font-weight: 600;
        border-bottom: 2px solid #dee2e6;
    }
    
    #devis-list-table td {
        vertical-align: middle;
    }
    
    .btn-group .btn {
        margin-right: 2px;
    }
    
    .btn-group .btn:last-child {
        margin-right: 0;
    }
    
    /* Print Devis Styles */
    .print-devis {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 0 auto;
        background: white;
        color: black;
    }
    
    .print-header {
        border-bottom: 2px solid #333;
        padding-bottom: 20px;
        margin-bottom: 30px;
    }
    
    .company-info {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 20px;
    }
    
    .company-logo {
        width: 120px;
        height: 80px;
        background: #f8f9fa;
        border: 1px solid #ddd;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        color: #666;
    }
    
    .company-details {
        text-align: right;
        font-size: 14px;
    }
    
    .devis-title {
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        margin: 20px 0;
        text-transform: uppercase;
        letter-spacing: 2px;
    }
    
    .client-info {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 30px;
    }
    
    .print-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }
    
    .print-table th {
        background: #333;
        color: white;
        padding: 12px 8px;
        text-align: center;
        font-weight: bold;
        border: 1px solid #333;
    }
    
    .print-table td {
        padding: 10px 8px;
        border: 1px solid #ddd;
        vertical-align: top;
    }
    
    .print-table tr:nth-child(even) {
        background: #f9f9f9;
    }
    
    .service-description {
        font-size: 12px;
        line-height: 1.4;
    }
    
    .quantity-list {
        text-align: center;
        font-weight: bold;
    }
    
    .print-footer {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 1px solid #ddd;
        font-size: 12px;
        color: #666;
    }
    
    @media print {
        .print-devis {
            margin: 0;
            max-width: none;
        }
        
        .modal-header,
        .modal-footer {
            display: none !important;
        }
        
        .modal-body {
            padding: 0 !important;
        }
    }
    
    .badge {
        font-size: 0.75rem;
        padding: 0.375rem 0.75rem;
    }
    
    /* Searchable Dropdown Styles */
    #package_dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        z-index: 1000;
        border: 1px solid #dee2e6;
        border-radius: 0.375rem;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        background: white;
    }
    
    .package-option {
        padding: 0.75rem 1rem;
        border-bottom: 1px solid #f8f9fa;
        transition: background-color 0.15s ease-in-out;
    }
    
    .package-option.highlighted {
        background-color: #e9ecef;
    }
    
    .package-option:last-child {
        border-bottom: none;
    }
    
    #package_search:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
</style>
@endpush

@section('content')
<div class="card border-0 shadow-sm">
    <!-- Profile Header -->
    <div class="customer-profile-header">
        <div class="row align-items-center">
            <div class="col-auto">
                <div class="profile-image-container">
                    <img src="{{ $data->profile_image ?? default_user_avatar() }}" 
                         alt="{{ $data->full_name }}" 
                         class="img-fluid rounded-circle profile-avatar">
                </div>
            </div>
            <div class="col">
                <h2 class="mb-2">{{ $data->full_name ?? 'N/A' }}</h2>
                <p class="mb-3 opacity-75">{{ $data->email ?? 'N/A' }}</p>
                <div class="d-flex gap-3">
                    @if($data->email_verified_at)
                        <span class="badge bg-light text-success px-3 py-2">
                            <i class="fa-solid fa-check-circle me-1"></i>
                            {{ __('customer.msg_verified') }}
                        </span>
                    @else
                        <span class="badge bg-light text-danger px-3 py-2">
                            <i class="fa-solid fa-times-circle me-1"></i>
                            {{ __('customer.msg_unverified') }}
                        </span>
                    @endif
                    
                    @if($data->status)
                        <span class="badge bg-light text-success px-3 py-2">
                            <i class="fa-solid fa-user-check me-1"></i>
                            {{ __('messages.active') }}
                        </span>
                    @else
                        <span class="badge bg-light text-danger px-3 py-2">
                            <i class="fa-solid fa-user-times me-1"></i>
                            {{ __('messages.inactive') }}
                        </span>
                    @endif
                </div>
            </div>
            <div class="col-auto">
                <a href="{{ route('backend.customers.index') }}" class="btn btn-light btn-lg">
                    <i class="fa-solid fa-arrow-left me-2"></i> {{ __('messages.back') }}
                </a>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <ul class="nav nav-tabs nav-tabs-custom" id="customerTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab" aria-controls="info" aria-selected="true">
                <i class="fa-solid fa-user me-2"></i>
                {{ __('Informations') }}
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="devis-tab" data-bs-toggle="tab" data-bs-target="#devis" type="button" role="tab" aria-controls="devis" aria-selected="false">
                <i class="fa-solid fa-file-invoice me-2"></i>
                {{ __('messages.devis') }}
            </button>
        </li>
        {{-- <li class="nav-item" role="presentation">
            <button class="nav-link" id="devis-list-tab" data-bs-toggle="tab" data-bs-target="#devis-list" type="button" role="tab" aria-controls="devis-list" aria-selected="false">
                <i class="fa-solid fa-list me-2"></i>
                {{ __('messages.devis_list') }}
            </button>
        </li> --}}
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="devis-history-tab" data-bs-toggle="tab" data-bs-target="#devis-history" type="button" role="tab" aria-controls="devis-history" aria-selected="false">
                <i class="fa-solid fa-history me-2"></i>
                {{ __('customer::show.devis_history') }}
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="medical-records-tab" data-bs-toggle="tab" data-bs-target="#medical-records" type="button" role="tab" aria-controls="medical-records" aria-selected="false">
                <i class="fa-solid fa-notes-medical me-2"></i>
                Medical Records
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="medical-history-tab" data-bs-toggle="tab" data-bs-target="#medical-history" type="button" role="tab" aria-controls="medical-history" aria-selected="false">
                <i class="fa-solid fa-briefcase-medical me-2"></i>
                Medical History
            </button>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content tab-content-custom" id="customerTabsContent">
        <!-- Info Tab -->
        <div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
            <div class="row">
                <!-- Personal Information -->
                <div class="col-lg-6">
                    <h5 class="mb-4 text-primary">
                        <i class="fa-solid fa-id-card me-2"></i>
                        {{ __('messages.personal_information') }}
                    </h5>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_first_name') }}</div>
                        <div class="info-value">{{ $data->first_name ?? 'N/A' }}</div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_last_name') }}</div>
                        <div class="info-value">{{ $data->last_name ?? 'N/A' }}</div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_Email') }}</div>
                        <div class="info-value">{{ $data->email ?? 'N/A' }}</div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_phone_number') }}</div>
                        <div class="info-value">{{ $data->phone_number ?? 'N/A' }}</div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_gender') }}</div>
                        <div class="info-value">{{ ucfirst($data->gender ?? 'N/A') }}</div>
                    </div>
                </div>

                <!-- Account Status -->
                <div class="col-lg-6">
                    <h5 class="mb-4 text-primary">
                        <i class="fa-solid fa-shield-alt me-2"></i>
                        {{ __('messages.account_status') }}
                    </h5>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_verification_status') }}</div>
                        <div class="info-value">
                            @if($data->email_verified_at)
                                <span class="status-badge bg-success text-white">
                                    <i class="fa-solid fa-check-circle me-1"></i>
                                    {{ __('customer.msg_verified') }}
                                </span>
                            @else
                                <span class="status-badge bg-danger text-white">
                                    <i class="fa-solid fa-times-circle me-1"></i>
                                    {{ __('customer.msg_unverified') }}
                                </span>
                            @endif
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_status') }}</div>
                        <div class="info-value">
                            @if($data->status)
                                <span class="status-badge bg-success text-white">
                                    <i class="fa-solid fa-user-check me-1"></i>
                                    {{ __('messages.active') }}
                                </span>
                            @else
                                <span class="status-badge bg-danger text-white">
                                    <i class="fa-solid fa-user-times me-1"></i>
                                    {{ __('messages.inactive') }}
                                </span>
                            @endif
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('customer.lbl_blocked') }}</div>
                        <div class="info-value">
                            @if($data->is_banned)
                                <span class="status-badge bg-danger text-white">
                                    <i class="fa-solid fa-ban me-1"></i>
                                    {{ __('messages.yes') }}
                                </span>
                            @else
                                <span class="status-badge bg-success text-white">
                                    <i class="fa-solid fa-check me-1"></i>
                                    {{ __('messages.no') }}
                                </span>
                            @endif
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('messages.created_at') }}</div>
                        <div class="info-value">{{ $data->created_at ? $data->created_at->format('M d, Y H:i A') : 'N/A' }}</div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-label">{{ __('messages.updated_at') }}</div>
                        <div class="info-value">{{ $data->updated_at ? $data->updated_at->format('M d, Y H:i A') : 'N/A' }}</div>
                    </div>
                </div>
            </div>
            
            <!-- Custom Fields -->
            @if(isset($data->custom_field_data) && !empty($data->custom_field_data))
            <div class="custom-fields-section">
                <h5 class="mb-4 text-primary">
                    <i class="fa-solid fa-list me-2"></i>
                    {{ __('messages.custom_fields') }}
                </h5>
                <div class="row">
                    @foreach($data->custom_field_data as $field => $value)
                    <div class="col-md-6">
                        <div class="info-card">
                            <div class="info-label">{{ ucwords(str_replace('_', ' ', $field)) }}</div>
                            <div class="info-value">{{ $value ?? 'N/A' }}</div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>

        <!-- Devis Tab -->
        <div class="tab-pane fade" id="devis" role="tabpanel" aria-labelledby="devis-tab">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 text-primary">
                    <i class="fa-solid fa-file-invoice me-2"></i>
                    {{ __('messages.devis') }}
                </h5>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createDevisModal">
                    <i class="fa-solid fa-plus me-2"></i>
                    {{ __('messages.create_devis') }}
                </button>
            </div>
            
            <!-- Devis List -->
            <div id="devis-list">
                <div class="empty-tab" id="empty-devis">
                    <i class="fa-solid fa-file-invoice"></i>
                    <h4>{{ __('messages.no_devis_available') }}</h4>
                    <p>{{ __('messages.click_create_devis_to_start') }}</p>
                </div>
                
                <!-- Services Table -->
                <div id="services-table-container" style="display: none;">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fa-solid fa-list me-2"></i>
                                {{ __('messages.added_services') }}
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped" id="services-table">
                                    <thead>
                                        <tr>
                                            <th>{{ __('messages.service_name') }}</th>
                                            <th>{{ __('messages.quantity') }}</th>
                                            <th>{{ __('messages.price') }}</th>
                                            <th>{{ __('messages.discount') }}</th>
                                            <th>{{ __('messages.subtotal') }}</th>
                                            <th>TVA %</th>
                                            <th>{{ __('messages.tax') }}</th>
                                            <th>{{ __('messages.total') }}</th>
                                            <th>Lot #</th>
                                            <th>{{ __('messages.remarks') }}</th>
                                            <th>{{ __('messages.actions') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody id="services-table-body">
                                        <!-- Services will be added here -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Summary -->
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-6">
                                                    <strong>{{ __('messages.subtotal') }}:</strong>
                                                </div>
                                                <div class="col-6 text-end">
                                                    $<span id="subtotal-amount">0.00</span>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6">
                                                    <strong>{{ __('messages.tax') }}:</strong>
                                                </div>
                                                <div class="col-6 text-end">
                                                    $<span id="tax-amount">20.00</span>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-6">
                                                    <strong>{{ __('messages.total_amount') }}:</strong>
                                                </div>
                                                <div class="col-6 text-end">
                                                    <strong>$<span id="total-amount">0.00</span></strong>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-grid gap-2">
                                        <button type="button" class="btn btn-success btn-lg" id="saveDevisBtn">
                                            <i class="fa-solid fa-save me-2"></i>
                                            {{ __('messages.save_devis') }}
                                        </button>
                                        <button type="button" class="btn btn-outline-primary" id="printDevisBtn">
                                            <i class="fa-solid fa-print me-2"></i>
                                            {{ __('messages.print_devis') }}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Devis List Tab -->
        <div class="tab-pane fade" id="devis-list" role="tabpanel" aria-labelledby="devis-list-tab">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 text-primary">
                    <i class="fa-solid fa-list me-2"></i>
                    {{ __('messages.devis_list') }}
                </h5>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary" id="refreshDevisList">
                        <i class="fa-solid fa-refresh me-2"></i>
                        {{ __('messages.refresh') }}
                    </button>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createDevisModal">
                        <i class="fa-solid fa-plus me-2"></i>
                        {{ __('messages.create_devis') }}
                    </button>
                </div>
            </div>
            
            <!-- Devis List Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="devis-list-table">
                            <thead>
                                <tr>
                                    <th>{{ __('messages.devis_number') }}</th>
                                    <th>{{ __('messages.package') }}</th>
                                    <th>{{ __('messages.subtotal') }}</th>
                                    <th>{{ __('messages.tax') }}</th>
                                    <th>{{ __('messages.total') }}</th>
                                    <th>{{ __('messages.created_at') }}</th>
                                    <th>{{ __('messages.valid_until') }}</th>
                                    <th>Number of Lot</th>
                                    <th>{{ __('messages.actions') }}</th>
                                </tr>
                            </thead>
                            <tbody id="devis-list-tbody">
                                <!-- Devis list will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Loading and Empty States -->
                    <div id="devis-list-loading" class="text-center py-4" style="display: none;">
                        <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
                        <p class="mt-2">{{ __('messages.loading') }}...</p>
                    </div>
                    
                    <div id="devis-list-empty" class="text-center py-5" style="display: none;">
                        <i class="fa-solid fa-file-invoice fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">{{ __('messages.no_devis_found') }}</h5>
                        <p class="text-muted">{{ __('messages.create_first_devis') }}</p>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createDevisModal">
                            <i class="fa-solid fa-plus me-2"></i>
                            {{ __('messages.create_devis') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Devis History Tab -->
        <div class="tab-pane fade" id="devis-history" role="tabpanel" aria-labelledby="devis-history-tab">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 text-primary">
                    <i class="fa-solid fa-history me-2"></i>
                    {{ __('customer::show.devis_history') }}
                </h5>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary" id="refreshDevisHistory">
                        <i class="fa-solid fa-refresh me-2"></i>
                        {{ __('customer::show.loading') }}
                    </button>
                </div>
            </div>
            
            <!-- Devis History Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="devis-history-table">
                            <thead class="table-dark">
                                <tr>
                                    <th>{{ __('messages.devis_number') }}</th>
                                    <th>{{ __('messages.package') }}</th>
                                    <th>{{ __('messages.subtotal') }}</th>
                                    <th>{{ __('messages.tax') }}</th>
                                    <th>{{ __('messages.total') }}</th>
                                    {{-- <th>{{ __('messages.status') }}</th> --}}
                                    <th>{{ __('messages.created_at') }}</th>
                                    <th>{{ __('messages.valid_until') }}</th>
                                    <th>{{ __('messages.number_of_lot') }}</th>
                                    <th>{{ __('messages.actions') }}</th>
                                </tr>
                            </thead>
                            <tbody id="devis-history-tbody">
                                <!-- Devis history will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Loading and Empty States -->
                    <div id="devis-history-loading" class="text-center py-4" style="display: none;">
                        <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
                        <p class="mt-2">{{ __('customer::show.loading') }}</p>
                    </div>
                    
                    <div id="devis-history-empty" class="text-center py-5" style="display: none;">
                        <i class="fa-solid fa-file-invoice fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">{{ __('customer::show.no_devis_available') }}</h5>
                        <p class="text-muted">{{ __('customer::show.no_services_in_package') }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Medical Records Tab -->
        <div class="tab-pane fade" id="medical-records" role="tabpanel" aria-labelledby="medical-records-tab">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="mb-0 text-primary">
                    <i class="fa-solid fa-notes-medical me-2"></i>
                    Medical Records
                </h5>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary" id="refreshMedicalRecords">
                        <i class="fa-solid fa-refresh me-2"></i>
                        {{ __('messages.refresh') }}
                    </button>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#medicalRecordModal">
                        <i class="fa-solid fa-file-circle-plus me-2"></i>
                        Add Document
                    </button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="medical-records-table">
                            <thead class="table-dark">
                                <tr>
                                    <th>Document</th>
                                    <th>Title</th>
                                    <th>Note</th>
                                    <th>Créé à / Modifié à</th>
                                    <th>{{ __('messages.actions') }}</th>
                                </tr>
                            </thead>
                            <tbody id="medical-records-tbody">
                                <!-- Records will be loaded here -->
                            </tbody>
                        </table>
                    </div>

                    <div id="medical-records-loading" class="text-center py-4" style="display: none;">
                        <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
                        <p class="mt-2">{{ __('customer::show.loading') }}</p>
                    </div>

                    <div id="medical-records-empty" class="text-center py-5" style="display: none;">
                        <i class="fa-solid fa-file-medical fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No medical records found</h5>
                        <p class="text-muted">Add the first medical document for this patient.</p>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#medicalRecordModal">
                            <i class="fa-solid fa-file-circle-plus me-2"></i>
                            Add Document
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Medical History Tab -->
        <div class="tab-pane fade" id="medical-history" role="tabpanel" aria-labelledby="medical-history-tab">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="mb-0 text-primary">
                    <i class="fa-solid fa-briefcase-medical me-2"></i>
                    Medical History
                </h5>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary" id="refreshMedicalHistory">
                        <i class="fa-solid fa-refresh me-2"></i> {{ __('messages.refresh') }}
                    </button>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#medicalHistoryModal">
                        <i class="fa-solid fa-plus me-2"></i> Add Antecedent
                    </button>
                </div>
            </div>

            <div id="mh-list">
                <div id="mh-loading" class="text-center py-4" style="display:none;">
                    <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
                    <p class="mt-2">{{ __('customer::show.loading') }}</p>
                </div>
                <div id="mh-empty" class="text-center py-5" style="display:none;">
                    <i class="fa-solid fa-heart-pulse fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No medical history yet</h5>
                    <p class="text-muted">Add the first antecedent for this patient.</p>
                </div>
                <div id="mh-items" class="vstack gap-2"></div>
            </div>
        </div>
    </div>
</div>

<div data-render="app">
    <change-password create-title="{{ __('messages.change_password') }}"></change-password>
</div>

<!-- Medical Record Create Modal -->
<div class="modal fade" id="medicalRecordModal" tabindex="-1" aria-labelledby="medicalRecordModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="medicalRecordModalLabel">
                    <i class="fa-solid fa-file-circle-plus me-2"></i>
                    Add Medical Document
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="medicalRecordForm" enctype="multipart/form-data">
                    <input type="hidden" name="customer_id" value="{{ $data->id }}">
                    <div class="mb-3">
                        <label for="mr_title" class="form-label">Title</label>
                        <input type="text" id="mr_title" name="title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="mr_note" class="form-label">Note</label>
                        <textarea id="mr_note" name="note" class="form-control" rows="3" placeholder="Optional"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="mr_file" class="form-label">Document File</label>
                        <input type="file" id="mr_file" name="document" class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx" required>
                        <div class="form-text">Allowed: PDF, Images, DOC, XLS</div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('messages.cancel') }}</button>
                <button type="button" class="btn btn-primary" id="saveMedicalRecordBtn">
                    <i class="fa-solid fa-save me-2"></i>
                    Save
                </button>
            </div>
        </div>
    </div>
 </div>

<!-- Medical History Create Modal -->
<div class="modal fade" id="medicalHistoryModal" tabindex="-1" aria-labelledby="medicalHistoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="medicalHistoryModalLabel">
                    <i class="fa-solid fa-plus me-2"></i>
                    Add Antecedent
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="medicalHistoryForm">
                    <input type="hidden" name="customer_id" value="{{ $data->id }}">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" name="title" id="mh_title" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <label class="form-label mb-0">Type</label>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="mhAddTypeBtn">
                                <i class="fa-solid fa-plus"></i> New Type
                            </button>
                        </div>
                        <select class="form-select mt-2" id="mh_type_id" name="type_id" required></select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Detail</label>
                        <textarea name="detail" id="mh_detail" class="form-control" rows="2" placeholder="Optional"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Médicament / traitement</label>
                        <input type="text" name="medication" id="mh_medication" class="form-control" placeholder="Optional">
                    </div>
                    <div class="row g-2">
                        <div class="col">
                            <label class="form-label">Start Date</label>
                            <input type="date" name="start_date" id="mh_start" class="form-control">
                        </div>
                        <div class="col">
                            <label class="form-label">End Date</label>
                            <input type="date" name="end_date" id="mh_end" class="form-control">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('messages.cancel') }}</button>
                <button type="button" class="btn btn-primary" id="saveMedicalHistoryBtn">
                    <i class="fa-solid fa-save me-2"></i> Save
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Create Devis Modal -->
<div class="modal fade" id="createDevisModal" tabindex="-1" aria-labelledby="createDevisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createDevisModalLabel">
                    <i class="fa-solid fa-file-invoice me-2"></i>
                    {{ __('messages.create_devis') }}
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="devisForm">
                    <input type="hidden" id="customer_id" value="{{ $data->id }}">
                    
                    <!-- Step Indicator -->
                    <div class="step-indicator">
                        <div class="step active" data-step="1">1</div>
                        <div class="step" data-step="2">2</div>
                        <div class="step" data-step="3">3</div>
                    </div>
                    
                    <!-- Step 1: Package Selection -->
                    <div id="step1" class="devis-step">
                        <h6 class="mb-3 text-primary">
                            <i class="fa-solid fa-box me-2"></i>
                            {{ __('messages.select_package') }}
                        </h6>
                        <div class="row">
                            <div class="col-md-12">
                                <label for="package_id" class="form-label">{{ __('messages.package') }}</label>
                                <div class="position-relative">
                                    <input type="text" class="form-control" id="package_search" placeholder="Search packages..." autocomplete="off">
                                    <select class="form-select" id="package_id" name="package_id" required style="display: none;">
                                        <option value="">{{ __('messages.select_package') }}</option>
                                    </select>
                                    <div id="package_dropdown" class="dropdown-menu w-100" style="display: none; max-height: 300px; overflow-y: auto;">
                                        <!-- Package options will be loaded here -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2: Package Details -->
                    <div id="step2" class="devis-step" style="display: none;">
                        <h6 class="mb-3 text-primary">
                            <i class="fa-solid fa-info-circle me-2"></i>
                            {{ __('messages.package_information') }}
                        </h6>
                        
                        <!-- Package Info Card -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h6 class="mb-0">{{ __('messages.package_details') }}</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <strong>{{ __('messages.package_name') }}:</strong>
                                        <span id="package_name_display"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>{{ __('messages.package_price') }}:</strong>
                                        <span id="package_price_display"></span>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-md-6">
                                        <strong>{{ __('messages.validity') }}:</strong>
                                        <span id="package_validity_display"></span>
                                    </div>
                                    <div class="col-md-6">
                                        <strong>{{ __('messages.branch') }}:</strong>
                                        <span id="package_branch_display"></span>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-md-12">
                                        <strong>{{ __('messages.description') }}:</strong>
                                        <p id="package_description_display" class="mt-1"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3: Service Customization -->
                    <div id="step3" class="devis-step" style="display: none;">
                        <h6 class="mb-3 text-primary">
                            <i class="fa-solid fa-cogs me-2"></i>
                            {{ __('messages.customize_services') }}
                        </h6>
                        
                        <!-- Services List -->
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">{{ __('messages.package_services') }}</h6>
                            </div>
                            <div class="card-body">
                                <div id="services_list">
                                    <!-- Services will be loaded here -->
                                </div>
                                
                                <!-- Add Service Button -->
                               
                                
                                <!-- Grand Total -->
                                <div class="row mt-4">
                                    <div class="col-md-8"></div>
                                    <div class="col-md-4">
                                        <div class="card bg-light">
                                            <div class="card-body text-end">
                                                <h5 class="mb-0">
                                                    <strong>{{ __('messages.grand_total') }}: $<span id="grand_total">0.00</span></strong>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <!-- Client Signature -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fa-solid fa-signature me-2"></i>
                                Client Signature
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row g-3 align-items-start">
                                <div class="col-12">
                                    <div class="border rounded" style="height: 220px; position: relative; background: #fff;">
                                        <canvas id="signature-canvas" style="width: 100%; height: 100%;"></canvas>
                                    </div>
                                    <div class="form-text mt-2">Please sign inside the box above.</div>
                                    <div class="mt-2">
                                        <span id="signature-status" class="badge bg-secondary">Empty</span>
                                    </div>
                                </div>
                                <div class="col-12 d-flex gap-2">
                                    <button type="button" class="btn btn-outline-secondary" id="signature-undo">Undo</button>
                                    <button type="button" class="btn btn-outline-danger" id="signature-clear">Clear</button>
                                </div>
                            </div>
                        </div>
                    </div>

                     
                        
                        <!-- Remarks Section -->
                        <div class="card mt-4">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fa-solid fa-comment me-2"></i>
                                    {{ __('messages.remarks') }}
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="devis_received_at" class="form-label">Devis reçu avant exécution (date)</label>
                                        <input type="date" class="form-control" id="devis_received_at" name="devis_received_at">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="devis_accepted_at" class="form-label">Devis accepté après réflexion (date)</label>
                                        <input type="date" class="form-control" id="devis_accepted_at" name="devis_accepted_at">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="devis_remarks" class="form-label">{{ __('messages.remarks') }}</label>
                                    <textarea class="form-control" id="devis_remarks" name="devis_remarks" rows="3" 
                                              placeholder="{{ __('messages.enter_remarks_here') }}"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    {{ __('messages.cancel') }}
                </button>
                <button type="button" class="btn btn-outline-primary" id="prevStep" style="display: none;">
                    <i class="fa-solid fa-arrow-left me-2"></i>
                    {{ __('messages.previous') }}
                </button>
                <button type="button" class="btn btn-primary" id="nextStep">
                    {{ __('messages.next') }}
                    <i class="fa-solid fa-arrow-right ms-2"></i>
                </button>
                <button type="button" class="btn btn-success" id="createDevis" style="display: none;">
                    <i class="fa-solid fa-save me-2"></i>
                    {{ __('messages.create_devis') }}
                </button>
            </div>
        </div>
    </div>
</div>

<!-- View Devis Details Modal -->
<div class="modal fade" id="viewDevisModal" tabindex="-1" aria-labelledby="viewDevisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewDevisModalLabel">
                    <i class="fa-solid fa-eye me-2"></i>
                    Devis Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Devis Header Info -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">Devis Information</h6>
                            </div>
                            <div class="card-body">
                                <p><strong>Devis Number:</strong> <span id="view_devis_number"></span></p>
                                <p><strong>Status:</strong> <span id="view_devis_status"></span></p>
                                <p><strong>Created Date:</strong> <span id="view_devis_created"></span></p>
                                <p><strong>Valid Until:</strong> <span id="view_devis_valid_until"></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">Package Information</h6>
                            </div>
                            <div class="card-body">
                                <p><strong>Package:</strong> <span id="view_package_name"></span></p>
                                <p><strong>Subtotal:</strong> $<span id="view_devis_subtotal"></span></p>
                                <p><strong>Tax Amount:</strong> $<span id="view_devis_tax"></span></p>
                                <p><strong>Total Amount:</strong> $<span id="view_devis_total"></span></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Services Details -->
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">Services Details</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped" id="view-services-table">
                                <thead>
                                    <tr>
                                        <th>Service Name</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Discount</th>
                                        <th>TVA %</th>
                                        <th>Subtotal</th>
                                        <th>Tax Amount</th>
                                        <th>Total</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody id="view-services-tbody">
                                    <!-- Services will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Remarks -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h6 class="mb-0">Remarks</h6>
                    </div>
                    <div class="card-body">
                        <p id="view_devis_remarks" class="mb-0"></p>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="printDevisBtn">
                    <i class="fa-solid fa-print me-2"></i>
                    Print
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Print Devis Modal -->
<div class="modal fade" id="printDevisModal" tabindex="-1" aria-labelledby="printDevisModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="printDevisModalLabel">
                    <i class="fa-solid fa-print me-2"></i>
                    Print Devis
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div id="print-content" class="p-4">
                    <!-- Print content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="actualPrintBtn">
                    <i class="fa-solid fa-print me-2"></i>
                    Print
                </button>
            </div>
        </div>
    </div>
</div>

@endsection

@push('after-scripts')
<script src="https://cdn.jsdelivr.net/npm/signature_pad@4.1.7/dist/signature_pad.umd.min.js"></script>
<script src="{{ mix('modules/customer/script.js') }}"></script>
<script src="{{ asset('js/form-modal/index.js') }}" defer></script>

<script>
$(document).ready(function() {
    let currentStep = 1;
    let selectedPackage = null;
    let packageServices = [];
    let addedServices = []; // Array to store all added services
    let serviceCounter = 0; // Counter for unique service IDs
    let taxRate = 0; // Current tax rate
    let availableTaxes = []; // Available tax options
    let signaturePad = null; // Signature pad instance
    let signatureImage = null; // Base64 of signature
    let capturedSignatureImage = null; // Persisted signature captured from modal

    // Load packages on modal open
    $('#createDevisModal').on('show.bs.modal', function() {
        loadPackages();
        loadTaxes();
        resetForm();
        initSignaturePad();
    });

    // Load packages
    function loadPackages() {
        $.ajax({
            url: '{{ route("backend.customers.get_packages") }}',
            method: 'GET',
            success: function(response) {
                console.log('Package API Response:', response);
                if (response.status) {
                    // Store packages globally for search functionality
                    window.availablePackages = response.data || [];
                    
                    // Populate the hidden select for form submission
                    const packageSelect = $('#package_id');
                    packageSelect.empty().append('<option value="">{{ __("messages.select_package") }}</option>');
                    
                    if (response.data && response.data.length > 0) {
                        response.data.forEach(function(package) {
                            packageSelect.append(`<option value="${package.id}">${package.name} - $${package.package_price}</option>`);
                        });
                        
                        // Populate the searchable dropdown
                        populatePackageDropdown(response.data);
                    } else {
                        packageSelect.append('<option value="" disabled>No packages available</option>');
                        $('#package_dropdown').html('<div class="dropdown-item text-muted">No packages available</div>');
                    }
                } else {
                    showAlert(response.message || 'Error loading packages', 'warning');
                }
            },
            error: function(xhr, status, error) {
                console.error('Package API Error:', xhr.responseText);
                showAlert('Error loading packages: ' + error, 'danger');
            }
        });
    }

    // Populate package dropdown for search
    function populatePackageDropdown(packages) {
        const dropdown = $('#package_dropdown');
        dropdown.empty();
        
        if (packages && packages.length > 0) {
            packages.forEach(function(package) {
                const option = $(`
                    <div class="dropdown-item package-option" data-package-id="${package.id}" style="cursor: pointer;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <strong>${package.name}</strong>
                                <br>
                                <small class="text-muted">$${package.package_price}</small>
                            </div>
                            <div class="text-end">
                                <small class="text-muted">${package.branch_name || 'N/A'}</small>
                            </div>
                        </div>
                    </div>
                `);
                dropdown.append(option);
            });
        } else {
            dropdown.html('<div class="dropdown-item text-muted">No packages available</div>');
        }
    }

    // Filter packages based on search
    function filterPackages(searchTerm) {
        const dropdown = $('#package_dropdown');
        const options = dropdown.find('.package-option');
        
        if (!searchTerm || searchTerm.trim() === '') {
            options.show();
            return;
        }
        
        const term = searchTerm.toLowerCase();
        options.each(function() {
            const text = $(this).text().toLowerCase();
            if (text.includes(term)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
        
        // Show "No results" if no options are visible
        const visibleOptions = dropdown.find('.package-option:visible');
        if (visibleOptions.length === 0) {
            dropdown.html('<div class="dropdown-item text-muted">No packages found</div>');
        }
    }

    // Package change event
    $('#package_id').on('change', function() {
        selectedPackage = $(this).val();
        if (selectedPackage) {
            loadPackageDetails(selectedPackage);
        }
    });

    // Package search functionality
    $('#package_search').on('focus', function() {
        $('#package_dropdown').show();
        filterPackages($(this).val());
    });

    $('#package_search').on('input', function() {
        const searchTerm = $(this).val();
        filterPackages(searchTerm);
        $('#package_dropdown').show();
    });

    // Hide dropdown when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#package_search, #package_dropdown').length) {
            $('#package_dropdown').hide();
        }
    });

    // Handle package selection from dropdown
    $(document).on('click', '.package-option', function() {
        const packageId = $(this).data('package-id');
        const packageText = $(this).find('strong').text();
        
        // Update the search input
        $('#package_search').val(packageText);
        
        // Update the hidden select
        $('#package_id').val(packageId);
        
        // Hide dropdown
        $('#package_dropdown').hide();
        
        // Load package details
        selectedPackage = packageId;
        if (selectedPackage) {
            loadPackageDetails(selectedPackage);
        }
    });

    // Handle keyboard navigation
    $('#package_search').on('keydown', function(e) {
        const dropdown = $('#package_dropdown');
        const options = dropdown.find('.package-option:visible');
        const current = dropdown.find('.package-option.highlighted');
        
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (current.length === 0) {
                options.first().addClass('highlighted');
            } else {
                current.removeClass('highlighted');
                current.next('.package-option:visible').addClass('highlighted');
            }
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (current.length === 0) {
                options.last().addClass('highlighted');
            } else {
                current.removeClass('highlighted');
                current.prev('.package-option:visible').addClass('highlighted');
            }
        } else if (e.key === 'Enter') {
            e.preventDefault();
            if (current.length > 0) {
                current.click();
            }
        } else if (e.key === 'Escape') {
            dropdown.hide();
        }
    });

    // Load package details and services
    function loadPackageDetails(packageId) {
        console.log('Loading package details for ID:', packageId);
        
        $.ajax({
            url: '{{ route("backend.customers.get_package_details") }}',
            method: 'GET',
            data: { package_id: packageId },
            success: function(response) {
                console.log('Package Details API Response:', response);
                if (response.status && response.data && response.data.length > 0) {
                    const package = response.data[0];
                    displayPackageInfo(package);
                    displayServices(package.services || []);
                } else {
                    console.error('No package data received:', response);
                    showAlert('No package data received', 'warning');
                }
            },
            error: function(xhr, status, error) {
                console.error('Package Details API Error:', xhr.responseText);
                console.error('Status:', status);
                console.error('Error:', error);
                
                let errorMessage = 'Error loading package details: ' + error;
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                
                showAlert(errorMessage, 'danger');
            }
        });
    }

    // Display package information
    function displayPackageInfo(package) {
        $('#package_name_display').text(package.name || 'N/A');
        $('#package_price_display').text(package.package_price ? '$' + package.package_price : 'N/A');
        $('#package_validity_display').text(package.end_date ? new Date(package.end_date).toLocaleDateString() : 'N/A');
        $('#package_branch_display').text(package.branch_name || 'N/A');
        $('#package_description_display').text(package.description || 'No description available');
    }

    // Load package services (now handled in loadPackageDetails)
    function loadPackageServices(packageId) {
        // This function is now handled in loadPackageDetails
        // Keeping for compatibility but not used
    }

    // Display services with customization options
    function displayServices(services) {
        let html = '';
        if (services.length === 0) {
            html = '<div class="text-center text-muted"><i class="fa-solid fa-exclamation-circle me-2"></i>No services found in this package</div>';
        } else {
            services.forEach(function(service, index) {
                const serviceId = `service_${serviceCounter++}`;
                html += `
                    <div class="service-item border rounded p-3 mb-3" data-service-id="${serviceId}" data-service-name="${service.service_name || 'N/A'}">
                        <div class="row align-items-center">
                            <div class="col-md-3">
                                <h6 class="mb-1">${service.service_name || 'N/A'}</h6>
                                <small class="text-muted">Duration: ${service.duration_min || 0} min</small>
                            </div>
                            <div class="col-md-1">
                                <label class="form-label small">Quantity</label>
                                <input type="number" class="form-control form-control-sm service-qty" 
                                       value="${service.quantity || 1}" 
                                       min="0" max="100">
                            </div>
                            <div class="col-md-1">
                                <label class="form-label small">Price</label>
                                <input type="number" class="form-control form-control-sm service-price" 
                                       value="${service.service_price || 0}" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-1">
                                <label class="form-label small">Discount</label>
                                <input type="number" class="form-control form-control-sm service-discount" 
                                       value="${service.discount_price || 0}" 
                                       step="0.01" min="0">
                            </div>
                            <div class="col-md-1">
                                <label class="form-label small">TVA %</label>
                                <input type="number" class="form-control form-control-sm service-tva" 
                                       value="20" step="0.01" min="0" max="100">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Lot #</label>
                                <input type="text" class="form-control form-control-sm service-lot" 
                                       placeholder="Lot #">
                            </div>
                            <div class="col-md-2">
                                <label class="form-label small">Total</label>
                                <input type="text" class="form-control form-control-sm service-total" 
                                       readonly>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="btn btn-sm btn-outline-danger remove-service" title="Remove Service">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <label class="form-label small">Service Remarks</label>
                                <input type="text" class="form-control form-control-sm service-remarks" 
                                       placeholder="Enter service remarks...">
                            </div>
                        </div>
                    </div>
                `;
            });
        }
        $('#services_list').html(html);
        
        // Add event listeners for calculations
        $('.service-qty, .service-price, .service-discount, .service-tva').on('input', calculateServiceTotal);
        $('.remove-service').on('click', removeService);
        calculateAllTotals();
    }

    // Load taxes
    function loadTaxes() {
        $.ajax({
            url: '{{ route("backend.customers.get_taxes") }}',
            method: 'GET',
            success: function(response) {
                console.log('Tax Response:', response);
                if (response.status) {
                    const taxSelect = $('#tax_id');
                    taxSelect.empty().append('<option value="">{{ __('messages.no_tax') }}</option>');
                    
                    if (response.data && response.data.length > 0) {
                        availableTaxes = response.data;
                        response.data.forEach(function(tax) {
                            taxSelect.append(`<option value="${tax.id}" data-type="${tax.type}" data-value="${tax.value}">${tax.title} (${tax.value}${tax.type === 'percent' ? '%' : '$'})</option>`);
                        });
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error('Tax Loading Error:', xhr.responseText);
                showAlert('Error loading taxes: ' + error, 'danger');
            }
        });
    }

    // Tax selection change
    $('#tax_id').on('change', function() {
        const selectedTax = $(this).find('option:selected');
        if (selectedTax.val()) {
            const type = selectedTax.data('type');
            const value = parseFloat(selectedTax.data('value'));
            taxRate = type === 'percent' ? value : (value / 100) * 100; // Convert fixed to percentage
            $('#custom_tax_rate').val(taxRate);
        } else {
            taxRate = 0;
            $('#custom_tax_rate').val('');
        }
        updateAllTotals();
    });

    // Custom tax rate change
    $('#custom_tax_rate').on('input', function() {
        taxRate = parseFloat($(this).val()) || 0;
        updateAllTotals();
    });

    // Calculate individual service total
    function calculateServiceTotal() {
        const qty = parseFloat($(this).closest('.service-item').find('.service-qty').val()) || 0;
        const price = parseFloat($(this).closest('.service-item').find('.service-price').val()) || 0;
        const discount = parseFloat($(this).closest('.service-item').find('.service-discount').val()) || 0;
        const tvaRate = parseFloat($(this).closest('.service-item').find('.service-tva').val()) || 0;
        
        const subtotal = qty * (price - discount);
        const taxAmount = (subtotal * tvaRate) / 100;
        const total = subtotal + taxAmount;
        
        $(this).closest('.service-item').find('.service-total').val(total.toFixed(2));
        updateAllTotals();
    }

    // Calculate grand total
    function calculateGrandTotal() {
        let grandTotal = 0;
        $('.service-total').each(function() {
            grandTotal += parseFloat($(this).val()) || 0;
        });
        
        // Update grand total display
        $('#grand_total').text(grandTotal.toFixed(2));
    }

    // Calculate all totals
    function calculateAllTotals() {
        $('.service-item').each(function() {
            const qty = parseFloat($(this).find('.service-qty').val()) || 0;
            const price = parseFloat($(this).find('.service-price').val()) || 0;
            const discount = parseFloat($(this).find('.service-discount').val()) || 0;
            const total = qty * (price - discount);
            $(this).find('.service-total').val(total.toFixed(2));
        });
        calculateGrandTotal();
    }

    // Next step button
    $('#nextStep').on('click', function() {
        if (currentStep === 1) {
            if (!$('#package_id').val()) {
                showAlert('Please select a package', 'warning');
                return;
            }
            currentStep = 2;
            updateStepIndicator(2);
            $('#step1').hide();
            $('#step2').show();
            $('#prevStep').show();
        } else if (currentStep === 2) {
            currentStep = 3;
            updateStepIndicator(3);
            $('#step2').hide();
            $('#step3').show();
            $('#nextStep').hide();
            $('#createDevis').show();
            // Ensure signature canvas is properly sized after becoming visible
            setTimeout(function() {
                if (typeof refreshSignatureCanvasSize === 'function') {
                    refreshSignatureCanvasSize();
                } else if (typeof initSignaturePad === 'function') {
                    initSignaturePad();
                }
            }, 150);
        }
    });

    // Previous step button
    $('#prevStep').on('click', function() {
        if (currentStep === 2) {
            currentStep = 1;
            updateStepIndicator(1);
            $('#step2').hide();
            $('#step1').show();
            $('#prevStep').hide();
        } else if (currentStep === 3) {
            currentStep = 2;
            updateStepIndicator(2);
            $('#step3').hide();
            $('#step2').show();
            $('#nextStep').show();
            $('#createDevis').hide();
        }
    });

    // Create devis button
    $('#createDevis').on('click', function() {
        createDevis();
    });

    // Add service button click
    $('#addServiceBtn').on('click', function() {
        addNewService();
    });

    // Add new service function
    function addNewService() {
        const serviceId = `service_${serviceCounter++}`;
        const html = `
            <div class="service-item border rounded p-3 mb-3" data-service-id="${serviceId}">
                <div class="row align-items-center">
                    <div class="col-md-3">
                        <label class="form-label small">Service Name</label>
                        <input type="text" class="form-control form-control-sm service-name" 
                               placeholder="Enter service name...">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small">Quantity</label>
                        <input type="number" class="form-control form-control-sm service-qty" 
                               value="1" min="0" max="100">
                    </div>
                    <div class="col-md-5">
                        <div class="d-flex align-items-end gap-2">
                            <div style="width: 20%">
                                <label class="form-label small">Quantity</label>
                                <input type="number" class="form-control form-control-sm service-qty" value="1" min="0" max="100">
                            </div>
                            <div style="width: 20%">
                                <label class="form-label small">Price</label>
                                <input type="number" class="form-control form-control-sm service-price" value="0" step="0.01" min="0">
                            </div>
                            <div style="width: 20%">
                                <label class="form-label small">Discount</label>
                                <input type="number" class="form-control form-control-sm service-discount" value="0" step="0.01" min="0">
                            </div>
                            <div style="width: 20%">
                                <label class="form-label small">TVA %</label>
                                <input type="number" class="form-control form-control-sm service-tva" value="20" step="0.01" min="0" max="100">
                            </div>
                            <div style="width: 20%">
                                <label class="form-label small">Lot #</label>
                                <input type="text" class="form-control form-control-sm service-lot" placeholder="Lot #">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small">Total</label>
                        <input type="text" class="form-control form-control-sm service-total" readonly>
                    </div>
                    <div class="col-md-1">
                        <button type="button" class="btn btn-sm btn-outline-danger remove-service" title="Remove Service">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12">
                        <label class="form-label small">Service Remarks</label>
                        <input type="text" class="form-control form-control-sm service-remarks" 
                               placeholder="Enter service remarks...">
                    </div>
                </div>
            </div>
        `;
        
        $('#services_list').append(html);
        
        // Add event listeners for the new service
        $(`[data-service-id="${serviceId}"] .service-qty, [data-service-id="${serviceId}"] .service-price, [data-service-id="${serviceId}"] .service-discount, [data-service-id="${serviceId}"] .service-tva`).on('input', calculateServiceTotal);
        $(`[data-service-id="${serviceId}"] .remove-service`).on('click', removeService);
        
        calculateAllTotals();
    }

    // Remove service function
    function removeService() {
        $(this).closest('.service-item').remove();
        calculateAllTotals();
    }

    // Create devis function - Only add to table, don't save to database
    function createDevis() {
        const packageId = $('#package_id').val();
        const remarks = $('#devis_remarks').val();
        
        // Collect service data
        const services = [];
        $('.service-item').each(function() {
            // Try to get service name from input field first, then from data attribute, then from display text
            let serviceName = $(this).find('.service-name').val();
            if (!serviceName) {
                // Try data attribute first
                serviceName = $(this).data('service-name');
                if (!serviceName) {
                    // For package services, get the name from the h6 element
                    serviceName = $(this).find('h6').text().trim() || 'Custom Service';
                }
            }
            
            const qty = parseInt($(this).find('.service-qty').val()) || 0;
            const price = parseFloat($(this).find('.service-price').val()) || 0;
            const discount = parseFloat($(this).find('.service-discount').val()) || 0;
            const tvaRate = parseFloat($(this).find('.service-tva').val()) || 0;
            const serviceRemarks = $(this).find('.service-remarks').val() || '';
            const numberOfLot = $(this).find('.service-lot').val() || '';
            
            if (qty > 0 && price > 0) {
                const serviceData = {
                    id: `temp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // Generate unique temp ID
                    service_name: serviceName,
                    quantity: qty,
                    price: price,
                    discount: discount,
                    tva_rate: tvaRate,
                    remarks: serviceRemarks,
                    number_of_lot: numberOfLot,
                    package_id: packageId,
                    modal_remarks: remarks
                };
                services.push(serviceData);
            }
        });

        if (services.length === 0) {
            showAlert('Please add at least one service with quantity and price', 'warning');
            return;
        }

        // Capture signature image now (modal will hide next)
        if (signaturePad && !signaturePad.isEmpty()) {
            capturedSignatureImage = signaturePad.toDataURL('image/png');
        } else {
            capturedSignatureImage = null;
        }

        // Add services to the table (don't save to database yet)
        addServicesToTable(services);
        
        // Show success message
        showAlert('Services added to table successfully!', 'success');
        
        // Hide modal and reset form
        $('#createDevisModal').modal('hide');
        resetForm();
    }

    // Add services to table
    function addServicesToTable(services) {
        // Hide empty state and show table
        $('#empty-devis').hide();
        $('#services-table-container').show();
        
        // Add services to addedServices array
        services.forEach(function(service) {
            addedServices.push(service);
        });
        
        // Add services to table body
        const tbody = $('#services-table-body');
        services.forEach(function(service) {
            const subtotal = service.quantity * (service.price - service.discount);
            const tvaRate = service.tva_rate || 0;
            const taxAmount = (subtotal * tvaRate) / 100;
            const total = subtotal + taxAmount;
            
            const row = `
                <tr data-service-id="${service.id}">
                    <td>${service.service_name}</td>
                    <td>${service.quantity}</td>
                    <td>$${service.price.toFixed(2)}</td>
                    <td>$${service.discount.toFixed(2)}</td>
                    <td>$${subtotal.toFixed(2)}</td>
                    <td>${tvaRate.toFixed(2)}%</td>
                    <td>$${taxAmount.toFixed(2)}</td>
                    <td>$${total.toFixed(2)}</td>
                    <td>${service.number_of_lot || '-'}</td>
                    <td>${service.remarks || '-'}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-outline-primary edit-service" title="Edit Service">
                            <i class="fa-solid fa-edit"></i>
                        </button>
                        <button type="button" class="btn btn-sm btn-outline-danger remove-table-service" title="Remove Service">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
            tbody.append(row);
        });
        
        // Add event listeners for table actions
        $('.edit-service').on('click', editService);
        $('.remove-table-service').on('click', removeTableService);
        
        // Update total amount
        updateTotalAmount();
    }

    // Edit service function
    function editService() {
        const row = $(this).closest('tr');
        const serviceId = row.data('service-id');
        
        // Find the service in addedServices array
        const serviceIndex = addedServices.findIndex(s => s.id === serviceId);
        if (serviceIndex !== -1) {
            const service = addedServices[serviceIndex];
            
            // Open modal with service data for editing
            $('#createDevisModal').modal('show');
            
            // Pre-fill the form with service data
            $('#package_id').val(selectedPackage);
            // You can add more pre-filling logic here
            
            showAlert('Edit functionality will be implemented', 'info');
        }
    }

    // Remove service from table
    function removeTableService() {
        const row = $(this).closest('tr');
        const serviceId = row.data('service-id');
        
        // Remove from addedServices array
        addedServices = addedServices.filter(s => s.id !== serviceId);
        
        // Remove from table
        row.remove();
        
        // Update total amount
        updateTotalAmount();
        
        // Show empty state if no services left
        if (addedServices.length === 0) {
            $('#empty-devis').show();
            $('#services-table-container').hide();
        }
        
        showAlert('Service removed successfully', 'success');
    }

    // Save devis button click
    $('#saveDevisBtn').on('click', function() {
        saveDevis();
    });

    // Print devis button click
    $('#printDevisBtn').on('click', function() {
        saveDevis(true);
    });

    // Save devis function - Save all services from table to database
    function saveDevis(shouldPrint = false) {
        if (addedServices.length === 0) {
            showAlert('No services to save', 'warning');
            return;
        }

        // Optional signature: attach if present; prefer captured image from modal
        signatureImage = capturedSignatureImage || ((signaturePad && !signaturePad.isEmpty()) ? signaturePad.toDataURL('image/png') : null);

        // Get package ID from the first service (if available) or use selected package
        const packageId = addedServices[0].package_id || selectedPackage;
        
        // Get remarks from the first service (if available) or use empty
        const remarks = addedServices[0].modal_remarks || '';

        const devisData = {
            customer_id: {{ $data->id }},
            package_id: packageId,
            services: addedServices.map(service => ({
                service_name: service.service_name,
                quantity: service.quantity,
                price: service.price,
                discount: service.discount,
                tva_rate: service.tva_rate || 0,
                remarks: service.remarks,
                number_of_lot: service.number_of_lot || ''
            })),
            tax_rate: taxRate,
            remarks: remarks,
            received_at: $('#devis_received_at').val() || null,
            accepted_at: $('#devis_accepted_at').val() || null,
            signature_image: signatureImage
        };

        console.log('Saving Devis:', devisData);
        
        // Show loading state
        const originalSaveHtml = $('#saveDevisBtn').html();
        const originalPrintHtml = $('#printDevisBtn').html();
        $('#saveDevisBtn').prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-2"></i>Saving...');
        $('#printDevisBtn').prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-2"></i>Saving...');
        
        $.ajax({
            url: '{{ route("backend.customers.save_devis") }}',
            method: 'POST',
            data: devisData,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                console.log('Save Devis Response:', response);
                if (response.status) {
                    showAlert(response.message || 'Devis saved successfully!', 'success');
                    
                    // Clear the table and reset everything
                    clearTable();
                    
                    // Refresh devis list if the devis list tab is active
                    if ($('#devis-list-tab').hasClass('active')) {
                        loadDevisList();
                    }
                    
                    // If triggered by print button, open PDF directly
                    if (shouldPrint && response.data && response.data.devis_id) {
                        const printUrl = `{{ route('backend.customers.print_devis_pdf', '') }}/${response.data.devis_id}`;
                        window.open(printUrl, '_blank');
                    }
                } else {
                    showAlert(response.message || 'Error saving devis', 'danger');
                }
            },
            error: function(xhr, status, error) {
                console.error('Save Devis Error:', xhr.responseText);
                let errorMessage = 'Error saving devis';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                    const errors = xhr.responseJSON.errors;
                    errorMessage = Object.values(errors).flat().join(', ');
                }
                
                showAlert(errorMessage, 'danger');
            },
            complete: function() {
                // Reset button state
                $('#saveDevisBtn').prop('disabled', false).html(originalSaveHtml);
                $('#printDevisBtn').prop('disabled', false).html(originalPrintHtml);
            }
        });
    }

    // Clear table function
    function clearTable() {
        // Clear the table body
        $('#services-table-body').empty();
        
        // Clear addedServices array
        addedServices = [];
        
        // Reset tax rate
        taxRate = 0;
        $('#tax_id').val('');
        $('#custom_tax_rate').val('');
        
        // Show empty state
        $('#empty-devis').show();
        $('#services-table-container').hide();
        
        // Reset totals
        $('#subtotal-amount').text('0.00');
        $('#tax-amount').text('0.00');
        $('#total-amount').text('0.00');

        // Clear signature
        if (signaturePad) {
            signaturePad.clear();
        }
        signatureImage = null;
    }

    // Generate devis content for printing
    function generateDevisContent() {
        let content = `
            <div class="header">
                <h1>Devis</h1>
                <p>Date: ${new Date().toLocaleDateString()}</p>
            </div>
            
            <div class="customer-info">
                <h3>Customer Information</h3>
                <p><strong>Name:</strong> {{ $data->full_name }}</p>
                <p><strong>Email:</strong> {{ $data->email }}</p>
                <p><strong>Phone:</strong> {{ $data->phone_number || 'N/A' }}</p>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Service Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Discount</th>
                        <th>Subtotal</th>
                        <th>Tax</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        addedServices.forEach(function(service) {
            const subtotal = service.quantity * (service.price - service.discount);
            const taxAmount = (subtotal * taxRate) / 100;
            const total = subtotal + taxAmount;
            
            content += `
                <tr>
                    <td>${service.service_name}</td>
                    <td>${service.quantity}</td>
                    <td>$${service.price.toFixed(2)}</td>
                    <td>$${service.discount.toFixed(2)}</td>
                    <td>$${subtotal.toFixed(2)}</td>
                    <td>$${taxAmount.toFixed(2)}</td>
                    <td>$${total.toFixed(2)}</td>
                </tr>
            `;
        });
        
        content += `
                </tbody>
            </table>
            
            <div class="total-section">
                <p>Subtotal: $${calculateSubtotal().toFixed(2)}</p>
                <p>Tax (${taxRate}%): $${calculateTaxAmount().toFixed(2)}</p>
                <p class="total-row">Total: $${calculateTotalAmount().toFixed(2)}</p>
            </div>
        `;
        
        return content;
    }

    // Calculate subtotal
    function calculateSubtotal() {
        let subtotal = 0;
        addedServices.forEach(function(service) {
            subtotal += service.quantity * (service.price - service.discount);
        });
        return subtotal;
    }

    // Calculate tax amount
    function calculateTaxAmount() {
        return (calculateSubtotal() * taxRate) / 100;
    }

    // Calculate total amount
    function calculateTotalAmount() {
        return calculateSubtotal() + calculateTaxAmount();
    }

    // Update all totals
    function updateAllTotals() {
        updateTotalAmount();
    }

    // Update total amount
    function updateTotalAmount() {
        // Calculate totals from addedServices array
        let subtotal = 0;
        let totalTaxAmount = 0;
        let total = 0;
        
        addedServices.forEach(function(service) {
            const serviceSubtotal = service.quantity * (service.price - service.discount);
            const serviceTvaRate = service.tva_rate || 0;
            const serviceTaxAmount = (serviceSubtotal * serviceTvaRate) / 100;
            
            subtotal += serviceSubtotal;
            totalTaxAmount += serviceTaxAmount;
        });
        
        total = subtotal + totalTaxAmount;
        
        // Update display
        $('#subtotal-amount').text(subtotal.toFixed(2));
        $('#tax-amount').text(totalTaxAmount.toFixed(2));
        $('#total-amount').text(total.toFixed(2));
    }

    // Calculate grand total amount
    function calculateGrandTotalAmount() {
        let total = 0;
        $('.service-total').each(function() {
            total += parseFloat($(this).val()) || 0;
        });
        return total;
    }

    // Update step indicator
    function updateStepIndicator(step) {
        $('.step').removeClass('active completed');
        for (let i = 1; i <= step; i++) {
            if (i < step) {
                $(`.step[data-step="${i}"]`).addClass('completed');
            } else {
                $(`.step[data-step="${i}"]`).addClass('active');
            }
        }
    }

    // Reset form
    function resetForm() {
        currentStep = 1;
        selectedPackage = null;
        packageServices = [];
        taxRate = 0;
        
        updateStepIndicator(1);
        $('#step1').show();
        $('#step2').hide();
        $('#step3').hide();
        $('#prevStep').hide();
        $('#nextStep').show();
        $('#createDevis').hide();
        
        $('#package_id').val('');
        $('#services_list').empty();
        $('#devis_remarks').val('');
        $('#tax_id').val('');
        $('#custom_tax_rate').val('');

        // Clear signature area if initialized
        if (signaturePad) {
            signaturePad.clear();
        }
        signatureImage = null;
    }

    // Initialize signature pad
    function initSignaturePad() {
        const canvas = document.getElementById('signature-canvas');
        if (!canvas) return;

        const resizeCanvasPreserve = () => {
            const data = signaturePad ? signaturePad.toData() : null;
            const ratio = Math.max(window.devicePixelRatio || 1, 1);
            const rect = canvas.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) return; // not visible yet
            canvas.width = rect.width * ratio;
            canvas.height = rect.height * ratio;
            const context = canvas.getContext('2d');
            context.scale(ratio, ratio);
            if (signaturePad && data && data.length) {
                signaturePad.clear();
                signaturePad.fromData(data);
            }
        };

        if (!signaturePad) {
            // First-time init
            signaturePad = new SignaturePad(canvas, {
                backgroundColor: 'rgba(255,255,255,1)',
                penColor: 'rgb(0, 0, 0)'
            });
            // Initial size
            resizeCanvasPreserve();
            // Resize on window changes
            window.addEventListener('resize', resizeCanvasPreserve);

            // Buttons
            $('#signature-clear').off('click').on('click', function() {
                if (signaturePad) signaturePad.clear();
                updateSignatureStatus();
            });
            $('#signature-undo').off('click').on('click', function() {
                if (!signaturePad) return;
                const data = signaturePad.toData();
                if (data && data.length) {
                    data.pop();
                    signaturePad.fromData(data);
                }
                updateSignatureStatus();
            });
            // Update status on draw
            signaturePad.onBegin = updateSignatureStatus;
            signaturePad.onEnd = updateSignatureStatus;
        } else {
            // Already exists: just ensure correct sizing without clearing
            resizeCanvasPreserve();
        }
    }

    // Public helper to refresh canvas size without losing signature
    function refreshSignatureCanvasSize() {
        if (signaturePad) {
            initSignaturePad();
        } else {
            initSignaturePad();
        }
    }

    function updateSignatureStatus() {
        const $badge = $('#signature-status');
        if (!$badge.length) return;
        if (signaturePad && !signaturePad.isEmpty()) {
            $badge.removeClass('bg-secondary').addClass('bg-success').text('Signed');
        } else {
            $badge.removeClass('bg-success').addClass('bg-secondary').text('Empty');
        }
    }

    // Show alert function
    function showAlert(message, type) {
        // You can implement your preferred alert system here
        alert(message);
    }

    // Load devis list when tab is clicked
    $('#devis-list-tab').on('click', function() {
        console.log('Devis List tab clicked');
        
        // Wait for tab to be fully activated
        setTimeout(function() {
            // Add a test row first to verify table works
            $('#devis-list-tbody').html(`
                <tr>
                    <td><strong>TEST001</strong></td>
                    <td>Test Package</td>
                    <td>$100.00</td>
                    <td>$10.00</td>
                    <td><strong>$110.00</strong></td>
                    <td><span class="badge bg-success">Active</span></td>
                    <td>${new Date().toLocaleDateString()}</td>
                    <td>${new Date().toLocaleDateString()}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-primary" title="{{   __('messages.view_details') }}">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `);
            
            // Force table to be visible
            $('#devis-list-table').css({
                'display': 'table',
                'background-color': 'red',
                'border': '3px solid blue'
            }).show();
            $('#devis-list-loading').hide();
            $('#devis-list-empty').hide();
            
            console.log('Test row added, table should be visible');
            console.log('Table element:', $('#devis-list-table'));
            console.log('Table is visible:', $('#devis-list-table').is(':visible'));
            console.log('Table display style:', $('#devis-list-table').css('display'));
            console.log('Tab content visible:', $('#devis-list').is(':visible'));
            console.log('Tab has active class:', $('#devis-list').hasClass('active'));
            console.log('Table parent visible:', $('#devis-list-table').parent().is(':visible'));
            
            // Then load real data
            loadDevisList();
        }, 100);
    });

    // Refresh devis list button
    $('#refreshDevisList').on('click', function() {
        loadDevisList();
    });

    // Load devis history when tab is clicked
    $('#devis-history-tab').on('click', function() {
        console.log('Devis History tab clicked');
        loadDevisHistory();
    });

    // Load medical records when tab is clicked
    $('#medical-records-tab').on('click', function() {
        console.log('Medical Records tab clicked');
        loadMedicalRecords();
    });

    // Load medical history when tab is clicked
    $('#medical-history-tab').on('click', function() {
        console.log('Medical History tab clicked');
        loadMedicalHistory();
    });

    // Refresh devis history button
    $('#refreshDevisHistory').on('click', function() {
        loadDevisHistory();
    });

    // Refresh medical records button
    $('#refreshMedicalRecords').on('click', function() {
        loadMedicalRecords();
    });

    // Refresh medical history button
    $('#refreshMedicalHistory').on('click', function() {
        loadMedicalHistory();
    });

    // Save medical record
    $('#saveMedicalRecordBtn').on('click', function() {
        submitMedicalRecord();
    });

    // Create medical history
    $('#saveMedicalHistoryBtn').on('click', function() {
        submitMedicalHistory();
    });

    // Add new type
    $('#mhAddTypeBtn').on('click', function() {
        const name = prompt('Enter new type name');
        if (!name) return;
        $.ajax({
            url: `{{ route('backend.customers.medical_history.types') }}`,
            method: 'POST',
            data: { name: name },
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(resp) {
                if (resp.status && resp.data) {
                    loadMedicalHistoryTypes(resp.data.id);
                } else {
                    showAlert(resp.message || 'Error creating type', 'danger');
                }
            },
            error: function(xhr) {
                showAlert('Error creating type', 'danger');
            }
        });
    });

    // Load devis list function
    function loadDevisList() {
        $('#devis-list-loading').show();
        $('#devis-list-empty').hide();
        $('#devis-list-table').hide();
        
        $.ajax({
            url: '{{ route("backend.customers.customer_devis", $data->id) }}',
            method: 'GET',
            success: function(response) {
                console.log('Devis List Response:', response);
                $('#devis-list-loading').hide();
                
                if (response.status && response.data && response.data.length > 0) {
                    displayDevisList(response.data);
                    $('#devis-list-table').show();
                    console.log('Table should be visible now');
                } else {
                    $('#devis-list-empty').show();
                }
            },
            error: function(xhr, status, error) {
                console.error('Devis List Error:', xhr.responseText);
                $('#devis-list-loading').hide();
                $('#devis-list-empty').show();
                showAlert('Error loading devis list: ' + error, 'danger');
            }
        });
    }

    // Load medical history types
    function loadMedicalHistoryTypes(selectId = null) {
        $.ajax({
            url: `{{ route('backend.customers.medical_history.types') }}`,
            method: 'GET',
            success: function(resp) {
                const $sel = $('#mh_type_id');
                $sel.empty();
                if (resp.status && Array.isArray(resp.data) && resp.data.length) {
                    resp.data.forEach(function(t){
                        $sel.append(`<option value="${t.id}">${$('<div>').text(t.name).html()}</option>`);
                    });
                    if (selectId) $sel.val(selectId);
                } else {
                    $sel.append('<option value="" disabled>No types</option>');
                }
            }
        });
    }

    // Load medical history list
    function loadMedicalHistory() {
        $('#mh-loading').show();
        $('#mh-empty').hide();
        $('#mh-items').empty();

        // Ensure types available when opening modal later
        loadMedicalHistoryTypes();

        $.ajax({
            url: `{{ route('backend.customers.medical_history.index', $data->id) }}`,
            method: 'GET',
            success: function(resp) {
                $('#mh-loading').hide();
                let items = [];
                if (Array.isArray(resp)) items = resp;
                else if (resp && Array.isArray(resp.data)) items = resp.data;

                if (!items.length) {
                    $('#mh-empty').show();
                    return;
                }

                renderMedicalHistory(items);
            },
            error: function() {
                $('#mh-loading').hide();
                $('#mh-empty').show();
            }
        });
    }

    function renderMedicalHistory(items) {
        const $wrap = $('#mh-items');
        $wrap.empty();
        items.forEach(function(h) {
            const typeName = h.type && h.type.name ? h.type.name : '—';
            const period = (h.start_date ? new Date(h.start_date).toLocaleDateString() : '-') +
                           ' → ' + (h.end_date ? new Date(h.end_date).toLocaleDateString() : '-');
            const detail = h.detail ? $('<div>').text(h.detail).html() : '';
            const medication = h.medication ? $('<div>').text(h.medication).html() : '';
            const created = h.created_at ? new Date(h.created_at).toLocaleString() : '';
            const html = `
                <div class="alert alert-info d-flex justify-content-between align-items-start mb-2" role="alert">
                    <div>
                        <div class="fw-semibold">${$('<div>').text(h.title || '').html()}</div>
                        <div class="small text-muted">Type: ${$('<div>').text(typeName).html()}</div>
                        ${detail ? `<div class="mt-1">${detail}</div>` : ''}
                        ${medication ? `<div class="mt-1"><strong>Médicament:</strong> ${medication}</div>` : ''}
                        <div class="small mt-1"><strong>Période:</strong> ${period}</div>
                        ${created ? `<div class="small text-muted">Ajouté: ${created}</div>` : ''}
                    </div>
                    <div class="ms-3">
                        <button type="button" class="btn btn-sm btn-outline-danger mh-delete" data-id="${h.id}"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
            `;
            $wrap.append(html);
        });

        $('.mh-delete').off('click').on('click', function(){
            const id = $(this).data('id');
            if (!confirm('Delete this history item?')) return;
            const btn = $(this);
            const orig = btn.html();
            btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i>');
            $.ajax({
                url: `{{ route('backend.customers.medical_history.delete', '') }}/${id}`,
                method: 'DELETE',
                headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                success: function(resp){
                    if (resp.status) loadMedicalHistory();
                    else showAlert(resp.message || 'Error deleting', 'danger');
                },
                error: function(){ showAlert('Error deleting', 'danger'); },
                complete: function(){ btn.prop('disabled', false).html(orig); }
            });
        });
    }

    function submitMedicalHistory() {
        const form = document.getElementById('medicalHistoryForm');
        if (!form) return;
        const fd = new FormData(form);
        const btn = $('#saveMedicalHistoryBtn');
        const original = btn.html();
        btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-2"></i>Saving...');

        $.ajax({
            url: `{{ route('backend.customers.medical_history.store', $data->id) }}`,
            method: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(resp){
                if (resp.status) {
                    $('#medicalHistoryModal').modal('hide');
                    form.reset();
                    loadMedicalHistory();
                    showAlert('Antecedent added', 'success');
                } else {
                    showAlert(resp.message || 'Error saving history', 'danger');
                }
            },
            error: function(xhr){
                let msg = 'Error saving history';
                if (xhr.responseJSON && xhr.responseJSON.message) msg = xhr.responseJSON.message;
                showAlert(msg, 'danger');
            },
            complete: function(){ btn.prop('disabled', false).html(original); }
        });
    }

    // Display devis list in table
    function displayDevisList(devisList) {
        console.log('Displaying devis list:', devisList);
        const tbody = $('#devis-list-tbody');
        console.log('Found tbody element:', tbody.length);
        tbody.empty();
        
        devisList.forEach(function(devis, index) {
            console.log(`Processing devis ${index + 1}:`, devis);
            const statusBadge = getStatusBadge(devis.status);
            const createdDate = new Date(devis.created_at).toLocaleDateString();
            const validUntil = devis.valid_until ? new Date(devis.valid_until).toLocaleDateString() : 'N/A';
            
            const row = `
                <tr>
                    <td>
                        <strong>${devis.devis_number}</strong>
                    </td>
                    <td>
                        ${devis.package ? devis.package.name : 'N/A'}
                    </td>
                    <td>$${parseFloat(devis.subtotal).toFixed(2)}</td>
                    <td>$${parseFloat(devis.tax_amount).toFixed(2)}</td>
                    <td>
                        <strong>$${parseFloat(devis.total_amount).toFixed(2)}</strong>
                    </td>
                    <td>${createdDate}</td>
                    <td>${validUntil}</td>
                    <td>${devis.number_of_lot || '-'}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-primary view-devis" 
                                    data-devis-id="${devis.id}" title="{{ __('messages.view_details') }}">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success print-devis" 
                                    data-devis-id="${devis.id}" title="{{ __('messages.print') }}">
                                <i class="fa-solid fa-print"></i>   
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-warning edit-devis" 
                                    data-devis-id="${devis.id}" title="Edit">
                                <i class="fa-solid fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger delete-devis" 
                                    data-devis-id="${devis.id}" title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            console.log(`Adding row ${index + 1} to table`);
            tbody.append(row);
        });
        
        console.log('Total rows added:', tbody.find('tr').length);
        
        // Add event listeners for action buttons
        $('.view-devis').on('click', viewDevisDetails);
        $('.print-devis').on('click', printDevisDetails);
        $('.edit-devis').on('click', editDevisDetails);
        $('.delete-devis').on('click', deleteDevisDetails);
    }

    // Load devis history function
    function loadDevisHistory() {
        console.log('Loading devis history...');
        $('#devis-history-loading').show();
        $('#devis-history-empty').hide();
        $('#devis-history-table').hide();
        
        $.ajax({
            url: '{{ route("backend.customers.customer_devis", $data->id) }}',
            method: 'GET',
            success: function(response) {
                console.log('Devis History Response:', response);
                $('#devis-history-loading').hide();
                
                if (response.status && response.data && response.data.length > 0) {
                    displayDevisHistory(response.data);
                    $('#devis-history-table').show();
                } else {
                    $('#devis-history-empty').show();
                }
            },
            error: function(xhr, status, error) {
                console.error('Devis History Error:', xhr.responseText);
                $('#devis-history-loading').hide();
                $('#devis-history-empty').show();
                showAlert('Error loading devis history: ' + error, 'danger');
            }
        });
    }

    // Display devis history in table
    function displayDevisHistory(devisList) {
        console.log('Displaying devis history:', devisList);
        const tbody = $('#devis-history-tbody');
        tbody.empty();
        
        devisList.forEach(function(devis, index) {
            console.log(`Processing devis ${index + 1}:`, devis);
            const statusBadge = getStatusBadge(devis.status);
            const createdDate = new Date(devis.created_at).toLocaleDateString();
            const validUntil = devis.valid_until ? new Date(devis.valid_until).toLocaleDateString() : 'N/A';
            const numberOfLot = devis.number_of_lot || '-';
            const row = `
                <tr>
                    <td>
                        <strong>${devis.devis_number}</strong>
                    </td>
                    <td>
                        ${devis.package ? devis.package.name : 'N/A'}
                    </td>
                    <td>$${parseFloat(devis.subtotal).toFixed(2)}</td>
                    <td>$${parseFloat(devis.tax_amount).toFixed(2)}</td>
                    <td>
                        <strong>$${parseFloat(devis.total_amount).toFixed(2)}</strong>
                    </td>
                    <td>${createdDate}</td>
                    <td>${validUntil}</td>
                    <td>${devis.number_of_lot || '-'}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-primary view-devis-history" 
                                    data-devis-id="${devis.id}" title="View Details">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success print-devis-history" 
                                    data-devis-id="${devis.id}" title="Print">
                                <i class="fa-solid fa-print"></i>
                            </button>
                            
                            <button type="button" class="btn btn-sm btn-outline-danger delete-devis-history" 
                                    data-devis-id="${devis.id}" title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            
            tbody.append(row);
        });
        
        console.log('Total rows added to history table:', tbody.find('tr').length);
        
        // Add event listeners for action buttons
        $('.view-devis-history').on('click', viewDevisDetails);
        $('.print-devis-history').on('click', printDevisDetails);
        $('.edit-devis-history').on('click', editDevisDetails);
        $('.delete-devis-history').on('click', deleteDevisDetails);
    }

    // Get status badge HTML
    function getStatusBadge(status) {
        const statusMap = {
            'draft': '<span class="badge bg-secondary">Draft</span>',
            'sent': '<span class="badge bg-info">Sent</span>',
            'accepted': '<span class="badge bg-success">Accepted</span>',
            'rejected': '<span class="badge bg-danger">Rejected</span>',
            'expired': '<span class="badge bg-warning">Expired</span>'
        };
        return statusMap[status] || '<span class="badge bg-light text-dark">Unknown</span>';
    }

    // Load medical records
    function loadMedicalRecords() {
        $('#medical-records-loading').show();
        $('#medical-records-empty').hide();
        $('#medical-records-table').hide();

        $.ajax({
            url: `{{ route('backend.customers.medical_records.index', $data->id) }}`,
            method: 'GET',
            success: function(response) {
                console.log('Medical Records Response:', response);
                $('#medical-records-loading').hide();

                // Normalize records array regardless of wrapper
                let records = [];
                if (Array.isArray(response)) {
                    records = response;
                } else if (response && Array.isArray(response.data)) {
                    records = response.data;
                } else if (response && response.data && Array.isArray(response.data.data)) {
                    records = response.data.data; // handle paginator shape
                }

                if (records.length > 0) {
                    displayMedicalRecords(records);
                    $('#medical-records-table').show();
                } else {
                    $('#medical-records-empty').show();
                    $('#medical-records-table').hide();
                }
            },
            error: function(xhr, status, error) {
                console.error('Medical Records Error:', xhr.responseText);
                $('#medical-records-loading').hide();
                $('#medical-records-empty').show();
                showAlert('Error loading medical records: ' + error, 'danger');
            }
        });
    }

    // Render medical records
    function displayMedicalRecords(records) {
        const tbody = $('#medical-records-tbody');
        tbody.empty();

        if (!Array.isArray(records) || records.length === 0) {
            $('#medical-records-empty').show();
            $('#medical-records-table').hide();
            return;
        }

        const getFilePreviewHTML = function(rec) {
            const url = rec.file_url || rec.url || rec.download_url || '#';
            const name = rec.file_name || 'Document';
            const mime = (rec.mime_type || '').toLowerCase();
            const ext = (name.split('.').pop() || '').toLowerCase();

            const isImage = mime.startsWith('image/') || ['jpg','jpeg','png','gif','webp','bmp','svg'].includes(ext);
            const isPdf = mime === 'application/pdf' || ext === 'pdf';
            const isWord = mime.includes('word') || ['doc','docx'].includes(ext);
            const isExcel = mime.includes('sheet') || ['xls','xlsx','csv'].includes(ext);

            if (url === '#' || !url) {
                return '<span class="text-muted">-</span>';
            }

            if (isImage) {
                return `
                    <a href="${url}" target="_blank" class="d-inline-flex align-items-center text-decoration-none">
                        <img src="${url}" alt="${$('<div>').text(name).html()}" style="height:40px;width:auto;border-radius:4px;border:1px solid #eee;object-fit:cover;margin-right:8px;"/>
                        <span class="text-truncate" style="max-width:220px;" title="${$('<div>').text(name).html()}">${$('<div>').text(name).html()}</span>
                    </a>
                `;
            }

            if (isPdf) {
                return `
                    <a href="${url}" target="_blank" class="d-inline-flex align-items-center text-decoration-none">
                        <i class="fa-solid fa-file-pdf text-danger me-2"></i>
                        <span class="text-truncate" style="max-width:240px;" title="${$('<div>').text(name).html()}">${$('<div>').text(name).html()}</span>
                    </a>
                `;
            }

            if (isWord) {
                return `
                    <a href="${url}" target="_blank" class="d-inline-flex align-items-center text-decoration-none">
                        <i class="fa-solid fa-file-word text-primary me-2"></i>
                        <span class="text-truncate" style="max-width:240px;" title="${$('<div>').text(name).html()}">${$('<div>').text(name).html()}</span>
                    </a>
                `;
            }

            if (isExcel) {
                return `
                    <a href="${url}" target="_blank" class="d-inline-flex align-items-center text-decoration-none">
                        <i class="fa-solid fa-file-excel text-success me-2"></i>
                        <span class="text-truncate" style="max-width:240px;" title="${$('<div>').text(name).html()}">${$('<div>').text(name).html()}</span>
                    </a>
                `;
            }

            return `
                <a href="${url}" target="_blank" class="d-inline-flex align-items-center text-decoration-none">
                    <i class="fa-solid fa-file-lines text-secondary me-2"></i>
                    <span class="text-truncate" style="max-width:240px;" title="${$('<div>').text(name).html()}">${$('<div>').text(name).html()}</span>
                </a>
            `;
        };

        records.forEach(function(rec) {
            const createdAt = rec.created_at ? new Date(rec.created_at).toLocaleString() : 'N/A';
            const updatedAt = rec.updated_at ? new Date(rec.updated_at).toLocaleString() : 'N/A';
            const previewHtml = getFilePreviewHTML(rec);
            const fileUrl = rec.file_url || rec.url || rec.download_url || '#';

            const row = `
                <tr>
                    <td>${previewHtml}</td>
                    <td>${rec.title || '-'}</td>
                    <td>${rec.note ? $('<div>').text(rec.note).html() : '-'}</td>
                    <td>
                        <div><small class="text-muted">Créé:</small> ${createdAt}</div>
                        <div><small class="text-muted">Modifié:</small> ${updatedAt}</div>
                    </td>
                    <td>
                        <div class="btn-group" role="group">
                            <a href="${fileUrl}" target="_blank" class="btn btn-sm btn-outline-primary" title="View / Download">
                                <i class="fa-solid fa-download"></i>
                            </a>
                            <button type="button" class="btn btn-sm btn-outline-danger delete-medical-record" data-record-id="${rec.id}" title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            tbody.append(row);
        });

        // Bind delete handlers
        $('.delete-medical-record').off('click').on('click', deleteMedicalRecord);

        $('#medical-records-empty').hide();
        $('#medical-records-table').show();
    }

    // Submit new medical record
    function submitMedicalRecord() {
        const form = document.getElementById('medicalRecordForm');
        if (!form) return;

        const fd = new FormData(form);

        const btn = $('#saveMedicalRecordBtn');
        const original = btn.html();
        btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-2"></i>Saving...');

        $.ajax({
            url: `{{ route('backend.customers.medical_records.store', $data->id) }}`,
            method: 'POST',
            data: fd,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                console.log('Medical Record Save Response:', response);
                if (response.status) {
                    showAlert(response.message || 'Document saved successfully', 'success');
                    $('#medicalRecordModal').modal('hide');
                    resetMedicalRecordForm();
                    loadMedicalRecords();
                } else {
                    showAlert(response.message || 'Error saving document', 'danger');
                }
            },
            error: function(xhr, status, error) {
                console.error('Medical Record Save Error:', xhr.responseText);
                let msg = 'Error saving document';
                if (xhr.responseJSON && xhr.responseJSON.message) msg = xhr.responseJSON.message;
                showAlert(msg, 'danger');
            },
            complete: function() {
                btn.prop('disabled', false).html(original);
            }
        });
    }

    function resetMedicalRecordForm() {
        $('#medicalRecordForm')[0].reset();
    }

    function deleteMedicalRecord() {
        const recordId = $(this).data('record-id');
        if (!recordId) return;

        if (!confirm('Are you sure you want to delete this document?')) return;

        const btn = $(this);
        const original = btn.html();
        btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin"></i>');

        $.ajax({
            url: `{{ url('app/customers/medical-records') }}/${recordId}`,
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response.status) {
                    showAlert('Document deleted', 'success');
                    loadMedicalRecords();
                } else {
                    showAlert(response.message || 'Error deleting document', 'danger');
                }
            },
            error: function(xhr, status, error) {
                console.error('Medical Record Delete Error:', xhr.responseText);
                showAlert('Error deleting document: ' + error, 'danger');
            },
            complete: function() {
                btn.prop('disabled', false).html(original);
            }
        });
    }

    // View devis details
    function viewDevisDetails() {
        const devisId = $(this).data('devis-id');
        console.log('Viewing devis details for ID:', devisId);
        
        // Show loading state
        $('#viewDevisModal .modal-body').html(`
            <div class="text-center py-4">
                <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
                <p class="mt-2">Loading devis details...</p>
            </div>
        `);
        
        // Show the modal
        $('#viewDevisModal').modal('show');
        
        // Load devis details
        $.ajax({
            url: '{{ route("backend.customers.customer_devis", $data->id) }}',
            method: 'GET',
            success: function(response) {
                console.log('Devis details response:', response);
                
                if (response.status && response.data) {
                    // Find the specific devis
                    const devis = response.data.find(d => d.id == devisId);
                    
                    if (devis) {
                        console.log('Found devis, calling populateDevisModal...');
                        console.log('populateDevisModal function exists:', typeof window.populateDevisModal);
                        if (typeof window.populateDevisModal === 'function') {
                            window.populateDevisModal(devis);
                        } else {
                            console.error('populateDevisModal is not a function!');
                            $('#viewDevisModal .modal-body').html(`
                                <div class="alert alert-danger">
                                    <i class="fa-solid fa-exclamation-triangle me-2"></i>
                                    Function error: populateDevisModal not found
                                </div>
                            `);
                        }
                    } else {
                        $('#viewDevisModal .modal-body').html(`
                            <div class="alert alert-danger">
                                <i class="fa-solid fa-exclamation-triangle me-2"></i>
                                Devis not found!
                            </div>
                        `);
                    }
                } else {
                    $('#viewDevisModal .modal-body').html(`
                        <div class="alert alert-danger">
                            <i class="fa-solid fa-exclamation-triangle me-2"></i>
                            Error loading devis details!
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error loading devis details:', xhr.responseText);
                $('#viewDevisModal .modal-body').html(`
                    <div class="alert alert-danger">
                        <i class="fa-solid fa-exclamation-triangle me-2"></i>
                        Error loading devis details: ${error}
                    </div>
                `);
            }
        });
    }

    // Populate devis modal with data - moved here for proper scope
    window.populateDevisModal = function(devis) {
        console.log('Populating modal with devis:', devis);
        
        // Restore the original modal body structure
        $('#viewDevisModal .modal-body').html(`
            <!-- Devis Header Info -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Devis Information</h6>
                        </div>
                        <div class="card-body">
                            <p><strong>Devis Number:</strong> <span id="view_devis_number"></span></p>
                            <p><strong>Status:</strong> <span id="view_devis_status"></span></p>
                            <p><strong>Created Date:</strong> <span id="view_devis_created"></span></p>
                            <p><strong>Valid Until:</strong> <span id="view_devis_valid_until"></span></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Package Information</h6>
                        </div>
                        <div class="card-body">
                            <p><strong>Package:</strong> <span id="view_package_name"></span></p>
                            <p><strong>Subtotal:</strong> $<span id="view_devis_subtotal"></span></p>
                            <p><strong>Tax Amount:</strong> $<span id="view_devis_tax"></span></p>
                            <p><strong>Total Amount:</strong> $<span id="view_devis_total"></span></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Services Details -->
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Services Details</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="view-services-table">
                            <thead>
                                <tr>
                                    <th>Service Name</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Discount</th>
                                    <th>TVA %</th>
                                    <th>Subtotal</th>
                                    <th>Tax Amount</th>
                                    <th>Total</th>
                                    <th>Lot #</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody id="view-services-tbody">
                                <!-- Services will be loaded here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Remarks -->
            <div class="card mt-4">
                <div class="card-header">
                    <h6 class="mb-0">Remarks</h6>
                </div>
                <div class="card-body">
                    <p id="view_devis_remarks" class="mb-0"></p>
                </div>
            </div>
        `);
        
        // Populate basic devis information
        $('#view_devis_number').text(devis.devis_number);
        $('#view_devis_status').html(getStatusBadge(devis.status));
        $('#view_devis_created').text(new Date(devis.created_at).toLocaleDateString());
        $('#view_devis_valid_until').text(devis.valid_until ? new Date(devis.valid_until).toLocaleDateString() : 'N/A');
        $('#view_package_name').text(devis.package ? devis.package.name : 'N/A');
        $('#view_devis_subtotal').text(parseFloat(devis.subtotal).toFixed(2));
        $('#view_devis_tax').text(parseFloat(devis.tax_amount).toFixed(2));
        $('#view_devis_total').text(parseFloat(devis.total_amount).toFixed(2));
        $('#view_devis_remarks').text(devis.remarks || 'No remarks');
        
        // Populate services table
        const tbody = $('#view-services-tbody');
        tbody.empty();
        
        if (devis.devis_details && devis.devis_details.length > 0) {
            devis.devis_details.forEach(function(service) {
                const row = `
                    <tr>
                        <td>${service.service_name}</td>
                        <td>${service.quantity}</td>
                        <td>$${parseFloat(service.price).toFixed(2)}</td>
                        <td>$${parseFloat(service.discount).toFixed(2)}</td>
                        <td>${service.tva_rate || 0}%</td>
                        <td>$${parseFloat(service.subtotal).toFixed(2)}</td>
                        <td>$${parseFloat(service.tax_amount).toFixed(2)}</td>
                        <td>$${parseFloat(service.total).toFixed(2)}</td>
                        <td>${service.number_of_lot || '-'}</td>
                        <td>${service.remarks || '-'}</td>
                    </tr>
                `;
                tbody.append(row);
            });
        } else {
            tbody.append('<tr><td colspan="10" class="text-center text-muted">No services found</td></tr>');
        }

        // Append signature card if present
        const existingSignatureCard = $('#view_devis_signature_card');
        if (existingSignatureCard.length) existingSignatureCard.remove();
        const signatureSrc = devis.signature_image_url || devis.signature_image || null;
        if (signatureSrc) {
            const signatureCard = `
                <div class="card mt-4" id="view_devis_signature_card">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fa-solid fa-signature me-2"></i>Client Signature</h6>
                    </div>
                    <div class="card-body">
                        <img src="${signatureSrc}" alt="Client Signature" class="img-fluid" style="max-height:240px;">
                    </div>
                </div>
            `;
            $('#viewDevisModal .modal-body').append(signatureCard);
        }
    };

    // Print devis details
    function printDevisDetails() {
        const devisId = $(this).data('devis-id');
        console.log('Printing devis ID:', devisId);
        
        // Open the PDF template in a new window/tab
        const printUrl = `{{ route('backend.customers.print_devis_pdf', '') }}/${devisId}`;
        window.open(printUrl, '_blank');
    }

    // Populate print modal with professional layout
    window.populatePrintModal = function(devis) {
        console.log('Populating print modal with devis:', devis);
        
        const createdDate = new Date(devis.created_at).toLocaleDateString('fr-FR');
        const validUntil = devis.valid_until ? new Date(devis.valid_until).toLocaleDateString('fr-FR') : 'N/A';
        
        // Generate quantity list (1-2-3-4-5)
        const quantityList = '1 - 2 - 3 - 4 - 5';
        
        // Build services table rows
        let servicesRows = '';
        if (devis.devis_details && devis.devis_details.length > 0) {
            devis.devis_details.forEach(function(service, index) {
                const tvaRate = service.tva_rate || 0;
                const tvaAmount = parseFloat(service.tax_amount).toFixed(2);
                const totalWithTax = parseFloat(service.total).toFixed(2);
                
                servicesRows += `
                    <tr>
                        <td class="service-description">
                            ${service.service_name}
                            ${service.remarks ? '<br><small class="text-muted">' + service.remarks + '</small>' : ''}
                        </td>
                        <td class="text-end">${parseFloat(service.subtotal).toFixed(2)} €</td>
                        <td class="text-end">${tvaRate}%<br><small>${tvaAmount} €</small></td>
                        <td class="text-end"><strong>${totalWithTax} €</strong></td>
                        <td class="quantity-list">${quantityList}</td>
                        <td class="text-center">${service.number_of_lot || '-'}</td>
                    </tr>
                `;
            });
        } else {
            servicesRows = '<tr><td colspan="6" class="text-center text-muted">Aucun service trouvé</td></tr>';
        }
        
        // Calculate totals
        const subtotal = parseFloat(devis.subtotal).toFixed(2);
        const totalTax = parseFloat(devis.tax_amount).toFixed(2);
        const grandTotal = parseFloat(devis.total_amount).toFixed(2);
        
        const printContent = `
            <div class="print-devis">
                <!-- Header with Company Info -->
                <div class="print-header">
                    <div class="company-info">
                        <div class="company-logo">
                            LOGO<br>COMPANY
                        </div>
                        <div class="company-details">
                            <strong>T4 ESTHETICS</strong><br>
                            123 Rue de la Beauté<br>
                            75001 Paris, France<br>
                            Tél: +33 1 23 45 67 89<br>
                            Email: contact@t4esthetics.com<br>
                            SIRET: 123 456 789 00012
                        </div>
                    </div>
                </div>
                
                <!-- Devis Title -->
                <div class="devis-title">DEVIS N° ${devis.devis_number}</div>
                
                <!-- Client Information -->
                <div class="client-info">
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Client:</strong><br>
                            ${$('#customer_name').text() || 'Nom du Client'}<br>
                            ${$('#customer_email').text() || 'email@client.com'}<br>
                            ${$('#customer_phone').text() || 'Téléphone client'}
                        </div>
                        <div class="col-md-6">
                            <strong>Date de création:</strong> ${createdDate}<br>
                            <strong>Valide jusqu'au:</strong> ${validUntil}<br>
                            <strong>Statut:</strong> ${getStatusText(devis.status)}
                        </div>
                    </div>
                </div>
                
                <!-- Services Table -->
                <table class="print-table">
                    <thead>
                        <tr>
                            <th style="width: 35%;">TYPE D'ACTE</th>
                            <th style="width: 12%;">HONORAIRES HT</th>
                            <th style="width: 12%;">TVA 20%</th>
                            <th style="width: 12%;">HONORAIRES TTC</th>
                            <th style="width: 12%;">QUANTITÉ</th>
                            <th style="width: 17%;">NUMÉRO DE LOT</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="service-description">
                                <strong>Incluant la réalisation du dossier médical, l'analyse, la prise de photographies, l'environnement des soins et la réalisation des actes.</strong>
                            </td>
                            <td class="text-end">-</td>
                            <td class="text-end">-</td>
                            <td class="text-end">-</td>
                            <td class="quantity-list">-</td>
                            <td class="text-center">-</td>
                        </tr>
                        ${servicesRows}
                    </tbody>
                    <tfoot>
                        <tr style="background: #f8f9fa; font-weight: bold;">
                            <td class="text-end"><strong>TOTAL</strong></td>
                            <td class="text-end"><strong>${subtotal} €</strong></td>
                            <td class="text-end"><strong>${totalTax} €</strong></td>
                            <td class="text-end"><strong>${grandTotal} €</strong></td>
                            <td class="text-center">-</td>
                            <td class="text-center">-</td>
                        </tr>
                    </tfoot>
                </table>
                
                <!-- Footer -->
                <div class="print-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Conditions de paiement:</strong><br>
                            Paiement à la commande ou selon accord commercial.<br>
                            TVA en sus si applicable.
                        </div>
                        <div class="col-md-6">
                            <strong>Validité:</strong><br>
                            Ce devis est valable 30 jours à compter de sa date d'émission.<br>
                            Signature du client obligatoire pour validation.
                        </div>
                    </div>
                    <hr>
                    <div class="text-center mt-3">
                        <p><strong>Merci pour votre confiance</strong></p>
                        <p>T4 ESTHETICS - Votre partenaire beauté et bien-être</p>
                    </div>
                </div>
            </div>
        `;
        
        $('#print-content').html(printContent);
    };

    // Helper function to get status text in French
    function getStatusText(status) {
        const statusMap = {
            'draft': 'Brouillon',
            'sent': 'Envoyé',
            'accepted': 'Accepté',
            'rejected': 'Rejeté',
            'expired': 'Expiré'
        };
        return statusMap[status] || status;
    }

    // Edit devis details
    function editDevisDetails() {
        const devisId = $(this).data('devis-id');
        showAlert('Edit devis functionality will be implemented', 'info');
    }

    // Print button functionality
    $('#actualPrintBtn').on('click', function() {
        console.log('Print button clicked');
        
        // Hide modal header and footer for printing
        $('#printDevisModal .modal-header').hide();
        $('#printDevisModal .modal-footer').hide();
        
        // Trigger print
        window.print();
        
        // Show modal header and footer again after printing
        setTimeout(function() {
            $('#printDevisModal .modal-header').show();
            $('#printDevisModal .modal-footer').show();
        }, 1000);
    });

    // Delete devis details
    function deleteDevisDetails() {
        const devisId = $(this).data('devis-id');
        const devisNumber = $(this).closest('tr').find('td:first strong').text();
        
        if (confirm(`Are you sure you want to delete devis ${devisNumber}? This action cannot be undone.`)) {
            console.log('Deleting devis ID:', devisId);
            
            // Show loading state
            const deleteBtn = $(this);
            const originalHtml = deleteBtn.html();
            deleteBtn.html('<i class="fa-solid fa-spinner fa-spin"></i>');
            deleteBtn.prop('disabled', true);
            
            $.ajax({
                url: `{{ url('app/customers/delete-devis') }}/${devisId}`,
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    console.log('Delete response:', response);
                    
                    if (response.status) {
                        showAlert('Devis deleted successfully!', 'success');
                        
                        // Remove the row from the table
                        deleteBtn.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            
                            // Check if table is empty
                            const remainingRows = $('#devis-history-tbody tr').length;
                            if (remainingRows === 0) {
                                $('#devis-history-empty').show();
                                $('#devis-history-table').hide();
                            }
                        });
                    } else {
                        showAlert(response.message || 'Error deleting devis', 'danger');
                        deleteBtn.html(originalHtml);
                        deleteBtn.prop('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Delete error:', xhr.responseText);
                    showAlert('Error deleting devis: ' + error, 'danger');
                    deleteBtn.html(originalHtml);
                    deleteBtn.prop('disabled', false);
                }
            });
        }
    }
});
</script>
@endpush
